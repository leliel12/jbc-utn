cd /home/juan/UTN/Simulacion/lab_02/lab2UI/dist;
java -jar lab2UI.jar;
cd -;
