/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lab2ui;

import lab2ui.view.MainJFrame;

/**
 *
 * @author juan
 */
public class Main {

    
    
     /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            javax.swing.UIManager.setLookAndFeel(javax.swing.UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            String error="Failure in charge system Look and Feel";
            System.err.println(error);
            javax.swing.JOptionPane.showMessageDialog(null, error, "ERROR", javax.swing.JOptionPane.ERROR_MESSAGE);
        }
        MainJFrame.Open();
    }
    
    

}
