/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2ui.back;

import java.io.File;
import java.util.ArrayList;
import xmlparser.Classify;
import xmlparser.IO;
import xmlparser.Validator;

/**
 *
 * @author juan
 */
public class Connection {

    private ArrayList<Double> muestra;

    public Connection(File file) {
        IO xml = new IO(file);
        Validator v = new Validator();
        muestra = new ArrayList<Double>();
        String r = "";
        xml.open();
        while ((r = xml.getNext()) != null) {
            tryToAddDouble(r);
            v.addToComprobate(r);
        }
        xml.close();
        if (v.isValid() == false) {
            System.err.println("XML mal formado!");
            System.exit(2);
        }//if
    }

    public double[] getMuestra() {
        double[] d = new double[muestra.size()];
        d=this.Intercambio(d);
        for (int i = 0; i < d.length; i++) {
            d[i] = muestra.get(i).doubleValue();
        }
        return d;
    }

    private void tryToAddDouble(String r) {
        String clf = Classify.getClassify(r);
        if (clf.compareTo(Classify.VALUE) == 0) {
            try {
                double d = Double.parseDouble(r);
                muestra.add(new Double(d));
                System.out.println("->> " + r);
            } catch (Exception e) {
                System.out.println(e.getMessage());
                System.out.println("Se omite un valor: " + r);
            }//cath
        }//if
    }//trytoaddDouble
    private double[] Intercambio(double[] vector) {
        // metodo de la Burbuja
        // Orden:  n^2
        boolean ordenado = false;
        int i, j;
        double aux;
        int tam = vector.length;
        for (i = 0; i < tam - 1 && !ordenado; i++) {
            ordenado = true;
            for (j = 0; j < tam - i - 1; j++) {
                if (vector[j] > vector[j + 1]) {
                    ordenado = false;
                    aux = vector[j];
                    vector[j] = vector[j + 1];
                    vector[j + 1] = aux;
                }
            }

        }
        return vector;
    }
}
