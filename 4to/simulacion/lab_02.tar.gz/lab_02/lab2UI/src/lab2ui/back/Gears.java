/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2ui.back;

import java.io.File;
import java.util.Random;
import randomLib.numbers.JavaRandom;
import randomLib.numbers.exceptions.InvalidDoubleSeedsException;
import randomLib.variables.ExpNeg;
import randomLib.variables.Gamma;
import randomLib.variables.Normal;
import randomLib.variables.Poisson;
import randomLib.variables.Unif;
import randomLib.variables.models.Distribution;

/**
 *
 * @author juan
 */
public class Gears {

    private int porc; // porcentaje de valores muestrales a usar
    private double[] muestra; // la muestra original
    private int tamMuestraTotal; // tamaño de la muestra original
    private double[] generados; //vector de valores pertenecientes a una distribucion
    private Distribution dist; // distribucion generador de generados
    
    
    //parametros muestrales
private double a;
private double b;
private double mu;
private double sigma; 
private double lambda;
private double recorrido;
    
    //parametros de los generados
private double gen_a;
private double gen_b;
private double gen_mu;
private double gen_sigma; 
private double gen_lambda;
private double gen_recorrido;
    
    public Gears(File file, int porc) {
        this.porc = porc;
        Connection c = new Connection(file);
        muestra = c.getMuestra();
        this.tamMuestraTotal = muestra.length;
    }//contructor
    
    public void setNewDistribution(String disName) {
        double[] d = this.getPorcMuestra();
        JavaRandom rand=null;
        a = Calculus.getMinInt(d);
        b = Calculus.getMaxInt(d);
        mu = Calculus.getMu(d);
        sigma = Calculus.getSig(d);
        lambda = Calculus.getLambda(d);
        recorrido = Calculus.getRecDouble(d);
        try {
            rand = new JavaRandom(new Random().nextDouble());
            dist = null;
            System.gc();
        } catch (InvalidDoubleSeedsException ex) {
        }
        if (isSelectedMethod("Gamma", disName)) {
            dist = new Gamma(rand,getLambda(), 0);
            System.out.println("Gamma");
        }
        if (isSelectedMethod("Exponencial Negativa", disName)) {
            dist = new ExpNeg(rand,getLambda());
            System.out.println("Exp Neg");
        }
        if (isSelectedMethod("Normal (Gaussiana)", disName)) {
            dist = new Normal(rand,getMu(),getSigma());
            System.out.println("Gaus");
        }
        if (isSelectedMethod("Poisson", disName)) {
            dist = new Poisson(rand,getLambda());
            System.out.println("Poisson");
        }
        if (isSelectedMethod("Bipuntual (uniforme)", disName)) {
            dist = new Unif(rand,getA(),getB());
            System.out.println("Bip");
        }
        generados = new double[d.length];
        for (int i = 0; i < d.length; i++) {
            generados[i] = dist.getNextDouble();
        }
        gen_a = Calculus.getMinInt(generados);
        gen_b = Calculus.getMaxInt(generados);
        gen_mu = Calculus.getMu(generados);
        gen_sigma = Calculus.getSig(generados);
        gen_lambda = Calculus.getLambda(generados);
        gen_recorrido=Calculus.getRecDouble(generados);
    }

    public double[] genGenerados(){
        return this.generados;
    }
    
    public double[] getPorcMuestra() {
        int p = (int) (this.getTamMuestraTotal() * ((float)this.getPorc() / 100));
        System.out.println(">>>>>>>>>>>>>>>> " +  String.valueOf(p));
        double[] d = new double[p];
        for (int i = 0; i < p; i++) {
            d[i] = muestra[i];
        }
        return d;
    }

    private boolean isSelectedMethod(String string, String disName) {
        return string.compareTo(disName) == 0;
    }

    public int getPorc() {
        return porc;
    }

    public void setPorc(int porc) {
        this.porc = porc;
    }

    public int getTamMuestraTotal() {
        return tamMuestraTotal;
    }

    public //vector de valores pertenecientes a una distribucion
    //parametros muestrales
    double getA() {
        return a;
    }

    public double getB() {
        return b;
    }

    public double getMu() {
        return mu;
    }

    public double getSigma() {
        return sigma;
    }

    public double getLambda() {
        return lambda;
    }

    public double getRecorrido() {
        return recorrido;
    }

    public double[] getGenerados() {
        return generados;
    }

    public double getGen_a() {
        return gen_a;
    }

    public double getGen_b() {
        return gen_b;
    }

    public double getGen_mu() {
        return gen_mu;
    }

    public double getGen_sigma() {
        return gen_sigma;
    }

    public double getGen_lambda() {
        return gen_lambda;
    }

    public double getGen_recorrido() {
        return gen_recorrido;
    }
} 
