/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lab2ui.back;

/**
 *
 * @author juan
 */
public class Calculus {

    
    public static double getRecDouble(double[] d){
        double a=d[0];
        double b=d[1];
        for(int i=0;i<d.length;i++){
            if(a>d[i])a=d[i];
            if(b<d[i])b=d[i];
        }
        return b-a;
    }
    
    public static double getMinInt(double[] d){
        double a=d[0];
        for(int i=0;i<d.length;i++){
            if(a>d[i])a=d[i];
        }
        a=(int)a;
        return a;
    }
    
    public static double getMaxInt(double[] d){
        double b=d[0];
        for(int i=0;i<d.length;i++){
            if(b<d[i])b=d[i];
        }
        b=(int)b+1;
        return b;
    }
    
    public static double getMu(double[] d){
        double mu=0;
        for(int i=0;i<d.length;i++){
            mu=mu+d[i];
        }
        return mu/d.length;
    }
    
    public static double getLambda(double[] d){
        return 1/getMu(d);
    }
    
    public static double getSig(double[] d){
        double des=0;
        double media=getMu(d);
        for(int i=0; i<d.length;i++){
            double a=d[i] - media;
            a= a*a;
            des=des+a;
        }
        des = des/(d.length -1);
        return Math.sqrt(des);
    }
    
}
