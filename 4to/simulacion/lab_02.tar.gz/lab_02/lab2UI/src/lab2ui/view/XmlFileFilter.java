/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2ui.view;

import java.io.File;

/**
 *
 * @author juan
 */
public class XmlFileFilter extends javax.swing.filechooser.FileFilter {

    @Override
    public boolean accept(File arg0) {
        if (arg0.isDirectory()) {
            return true;
        } else {
            try {
                String ext = arg0.getName();
                ext = ext.substring(ext.length() - 4);
                return ext.compareTo(".xml") == 0;

            } catch (Exception e) {
                return false;
            }
        }

    }

    @Override
    public String getDescription() {
        return "Xml file";
    }
}
