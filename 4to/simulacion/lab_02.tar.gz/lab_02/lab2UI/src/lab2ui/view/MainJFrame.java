/*
 * MainJFrame.java
 *
 * Created on 14 de abril de 2008, 15:13
 */
package lab2ui.view;


import graphicLib.HistogramaJPanel;
import graphicLib.InvalidPorcException;
import java.io.File;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import lab2ui.Info;
import lab2ui.back.Gears;

/**
 *
 * @author  juan
 */
public class MainJFrame extends javax.swing.JFrame {

    private Gears gear;
    private String mu;
    private String sig;
    private String a;
    private String b;
    private String n;
    private String lambda;
    private String cInt;
    private String pInt;

    public static void Open() {
        XmlFileFilter filter = new XmlFileFilter();
        JFileChooser jfd = new JFileChooser();
        jfd.setFileFilter(filter);
        if (jfd.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
            new MainJFrame(jfd.getSelectedFile()).setVisible(true);
        } else {
            System.exit(0);
        }
    }

    /** Creates new form MainJFrame */
    private MainJFrame(File file) {
        initComponents();
        gear = new Gears(file,100);
        this.cInt="20";
        this.pInt="100";
        this.mu = String.valueOf(gear.getMu()) + " / ";
        this.sig = String.valueOf(gear.getSigma()) + " / ";
        this.a = String.valueOf(gear.getA()) + " / ";
        this.b = String.valueOf(gear.getB()) + " / ";
        this.n = String.valueOf(gear.getTamMuestraTotal()) + " / ";
        this.lambda = String.valueOf(gear.getLambda()) + " / ";
        this.setResume();
    }

    /**
     * verifica si es o no el item que esta selecionado en el combobox
     * @param value texto del item a verificar
     * @return si el item esta seleccionado
     */
    private boolean isComboSelectedValue(String value) {
        return ((String) this.jComboBox1.getSelectedItem()).compareTo(value) == 0;
    }

    private void setResume() {
        try {
            int proc= Integer.parseInt(this.pInt);
            gear.setPorc(proc);
            gear.setNewDistribution((String) this.jComboBox1.getSelectedItem());
            String genMu = String.valueOf(gear.getGen_mu());
            String genSig = String.valueOf(gear.getGen_sigma());
            String genA = String.valueOf(gear.getGen_a());
            String genB = String.valueOf(gear.getGen_b());
            String genLamb = String.valueOf(gear.getGen_lambda());
            String genN = String.valueOf(gear.getGenerados().length);
            this.nTF.setText(this.n + genN);
            if (this.isComboSelectedValue("Gamma")) {
                this.muTF.setText("-");
                this.sigTF.setText("-");
                this.aTF.setText("-");
                this.bTF.setText("-");
                this.lambTF.setText(this.lambda + genLamb);
            }
            if (this.isComboSelectedValue("Bipuntual (uniforme)")) {
                this.muTF.setText(this.mu + genMu);
                this.sigTF.setText(this.sig + genSig);
                this.aTF.setText(this.a + genA);
                this.bTF.setText(this.b + genB);
                this.lambTF.setText("-");
            }
            if (this.isComboSelectedValue("Exponencial Negativa")) {
                this.muTF.setText("-");
                this.sigTF.setText("-");
                this.aTF.setText("-");
                this.bTF.setText("-");
                this.lambTF.setText(this.lambda + genLamb);
            }
            if (this.isComboSelectedValue("Normal (Gaussiana)")) {
                this.muTF.setText(this.mu + genMu);
                this.sigTF.setText(this.sig + genSig);
                this.aTF.setText("-");
                this.bTF.setText("-");
                this.lambTF.setText("-");
            }
            if (this.isComboSelectedValue("Poisson")) {
                this.muTF.setText("-");
                this.sigTF.setText("-");
                this.aTF.setText("-");
                this.bTF.setText("-");
                this.lambTF.setText(this.lambda + genLamb);
            }
            double[] arg0 = gear.getPorcMuestra();
            double[] arg1 = gear.getGenerados();
            this.jTable1.setModel(new TableModel(arg0, arg1));
            this.cIntTF.setText(this.cInt);
            this.pIntTF.setText(this.pInt + "%");
            

            String lx = "Lap";
            String ly = "Cantidad de Vehiculos";
            String tit = "Peaje a Carlos Paz";
            this.jPanel2.removeAll();
            JPanel his = HistogramaJPanel.getHistogramaJPanel(arg0, arg1, Integer.parseInt(this.cInt), lx, ly, tit, 1);
            this.jPanel2.add(his);
            this.jPanel2.setVisible(false);
            this.jPanel2.revalidate();
            this.jPanel2.setVisible(true);
        } catch (InvalidPorcException ex) {
            System.gc();
        }
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jComboBox1 = new javax.swing.JComboBox();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        nTF = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        muTF = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        sigTF = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        aTF = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        bTF = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        lambTF = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        cIntTF = new javax.swing.JTextField();
        pIntTF = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem3 = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JSeparator();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle(Info.PROGRAM_NAME + " - 4k3 - 2008");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Poisson", "Normal (Gaussiana)", "Bipuntual (uniforme)", "Exponencial Negativa", "Gamma" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jScrollPane1.setBorder(javax.swing.BorderFactory.createTitledBorder("Valores"));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jScrollPane2.setBorder(javax.swing.BorderFactory.createTitledBorder("Descripcion"));

        jTextArea1.setColumns(20);
        jTextArea1.setEditable(false);
        jTextArea1.setRows(5);
        jTextArea1.setText("Cantidad de Automoviles que pasaron\npor el peaje Cordoba - C.Paz\nel dia 06-04-2008, entre las 20. y 21 hs.\n\nLos Valores fueron tomados en \nlapsos de 5 minutos cada \n10 minutos");
        jScrollPane2.setViewportView(jTextArea1);

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Resumen (Observada/Generada)"));

        jLabel1.setText("Cantidad de Valores:");

        nTF.setEditable(false);
        nTF.setText("0/0");

        jLabel2.setText("Media:");

        muTF.setEditable(false);
        muTF.setText("0/0");

        jLabel3.setText("Desviacion Estandar:");

        sigTF.setEditable(false);
        sigTF.setText("0/0");

        jLabel4.setText("a:");

        aTF.setEditable(false);
        aTF.setText("0/0");

        jLabel5.setText("b:");

        bTF.setEditable(false);
        bTF.setText("0/0");

        jLabel6.setText("Lambda:");

        lambTF.setEditable(false);
        lambTF.setText("0/0");

        jLabel7.setText("Cantidad de Intervalos Para Graficar:");

        cIntTF.setEditable(false);
        cIntTF.setText("-");

        pIntTF.setEditable(false);
        pIntTF.setText("-");

        jLabel8.setText("Porcentaje de Intervalos Para Graficar:");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 206, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(bTF, javax.swing.GroupLayout.DEFAULT_SIZE, 332, Short.MAX_VALUE)
                            .addComponent(lambTF, javax.swing.GroupLayout.DEFAULT_SIZE, 332, Short.MAX_VALUE)
                            .addComponent(aTF, javax.swing.GroupLayout.DEFAULT_SIZE, 332, Short.MAX_VALUE)
                            .addComponent(sigTF, javax.swing.GroupLayout.DEFAULT_SIZE, 332, Short.MAX_VALUE)
                            .addComponent(muTF, javax.swing.GroupLayout.DEFAULT_SIZE, 332, Short.MAX_VALUE)
                            .addComponent(nTF, javax.swing.GroupLayout.DEFAULT_SIZE, 332, Short.MAX_VALUE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(305, 305, 305))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addGap(24, 24, 24)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(pIntTF, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 292, Short.MAX_VALUE)
                            .addComponent(cIntTF, javax.swing.GroupLayout.DEFAULT_SIZE, 292, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(nTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(muTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sigTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(aTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lambTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(cIntTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pIntTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 574, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 222, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 446, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 141, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );

        jTabbedPane1.addTab("Datos", jPanel1);

        jPanel2.setLayout(new java.awt.GridLayout(1, 1));
        jTabbedPane1.addTab("Grafico", jPanel2);

        jMenu1.setText("Archivo");

        jMenuItem3.setText("Opciones del Histograma");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem3);
        jMenu1.add(jSeparator1);

        jMenuItem2.setText("Salir");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Ayuda");

        jMenuItem1.setText("Acerca De...");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem1);

        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTabbedPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 834, Short.MAX_VALUE)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 507, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        setBounds((screenSize.width-868)/2, (screenSize.height-617)/2, 868, 617);
    }// </editor-fold>//GEN-END:initComponents
    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        System.exit(0);
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        this.setResume();
       
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        String name=Info.PROGRAM_NAME;
        String info=Info.INFO_RESUME;
        String aut=Info.AUTHORS;
        String licence=Info.LICENSE;
        ImageIcon splash=new ImageIcon(getClass().getResource("/lab2ui/resources/splash.png"));
        AboutJDialog.open(name, info, aut, licence, splash);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        int[] aux= new int[2];
        aux[0]=Integer.parseInt(this.cInt);
        System.out.println(aux[0]);
        aux[1]=Integer.parseInt(this.pInt);
        aux=lab2ui.view.IntervalImputJDialog.open(aux[0],aux[1]);
        if(aux[0]!=-1){
            this.cInt=String.valueOf(aux[0]);
            this.pInt=String.valueOf(aux[1]);
            this.setResume();
        }
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new MainJFrame(null).setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField aTF;
    private javax.swing.JTextField bTF;
    private javax.swing.JTextField cIntTF;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField lambTF;
    private javax.swing.JTextField muTF;
    private javax.swing.JTextField nTF;
    private javax.swing.JTextField pIntTF;
    private javax.swing.JTextField sigTF;
    // End of variables declaration//GEN-END:variables
}
