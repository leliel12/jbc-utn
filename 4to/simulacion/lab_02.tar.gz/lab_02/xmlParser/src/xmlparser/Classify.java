/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package xmlparser;

/**
 *
 * @author juan
 */
public abstract class Classify {

    public static final String TAG = "TAG";
    public static final String VALUE = "VALUE";
    public static final String COMMENTARY = "COMMENTARY";
    public static final String INVALID = "INVALID";
    private static String res = "";

    public static String getClassify(String str) {
        res = xmlparser.Classify.INVALID;
        if (str.charAt(0) == '<') {
            validateTC(str);
        } else {
            validateValue(str);
        }
        return res;
    }

    private static void validateValue(String str) {
        str.trim();
        if (str.indexOf("<") == -1 && str.indexOf(">") == -1) {
            res = VALUE;
        }
    }

    private static void validateTC(String str) {
        if (str.charAt(1) == '!') {
            validateComm(str);
        } else {
            validateTag(str);
        }
    }

    private static void validateTag(String str) {
        boolean ok = false;
        String aux = str.replaceAll("<", "").replaceAll(">", "").trim();
        ok = (str.charAt(str.length() - 1) == '>' && !aux.isEmpty());
        aux=str.substring(1,str.length()-1);
        ok = (aux.indexOf('<')==-1 && aux.indexOf('>')==-1 && ok);
        if (ok) {
            res = TAG;
        }
    }

    private static void validateComm(String str) {
        try {
            boolean ok=false;
            String f = str.substring(0, 4);
            String l = str.substring(str.length() - 3,str.length());
            ok = (f.compareTo("<!--") == 0 && l.compareTo("-->") == 0); 
            f=str.substring(1,str.length()-1).trim();
            ok= (ok && f.indexOf('<')==-1 && f.indexOf('>')==-1 && !f.isEmpty());
            if(ok){
                res=COMMENTARY;
            }
        } catch (Exception exception) {
            System.err.println(exception.getMessage());
        }

    }
}
