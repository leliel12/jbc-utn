/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package xmlparser;
import java.util.Stack;


/**
 *
 * @author juan
 */
public class Validator {

   private Stack<String> s;
   private boolean use;
    
    public Validator(){
        s = new Stack<String>();
        use=false;
    }
    
    public boolean isValid(){
        return s.isEmpty() && use;
    }
    
    public void addToComprobate(String tag){
        if(tag!=null){
        String str=Classify.getClassify(tag);
        if(str.compareTo(Classify.TAG)==0 && tag.substring(0,2).compareTo("<?")!=0) popOrPush(tag);
        }
    }

    private void popOrPush(String tag) {
        if (s.isEmpty()) {
            s.push(tag);
            use=true;
        } else {
            String aux1 = s.peek();
            aux1 = aux1.replaceAll("<", "").replaceAll(">", "");
            String aux2 = tag.replaceAll("</", "").replaceAll(">", "");
            if (aux1.compareTo(aux2) != 0) {
                s.push(tag);
            } else {
                s.pop();
            }
        }
    
}
}
