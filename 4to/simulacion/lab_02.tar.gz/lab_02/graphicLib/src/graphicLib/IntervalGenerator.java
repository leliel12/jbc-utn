/**
 *  Ejes.java
 * 
 *  Copyright (C) - 2008 - JBCabral - JMGuzman - FAGambino
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


package graphicLib;

/**
 * genera los intervalos
 * @author JBCabral - JMGuzman - FAGambino
 * @version 1.0
 */
class IntervalGenerator {

    //variables
    private double maxvector;
    private double minvector;
    private Intervalo[] vConstruir;
    private Intervalo[] vConstruir2;

    /**
     * contruye una nueva instancia
     * @param v vector de valores
     * @param cantIntervalos cantidad de intervalos
     */
    public IntervalGenerator(double[] v,int cantIntervalos){
        this.construirIntervalos(cantIntervalos, v);
        this.setValoresIntervalo(v,vConstruir);   
    }
    
    public IntervalGenerator(double[] v1,double[] v2,int cantIntervalos)
    {
        this.construirIntervalosDos(cantIntervalos,v1,v2);
        this.setValoresIntervalo(v1,vConstruir);
    //    this.construirIntervalos2(cantIntervalos, v2);
        this.setValoresIntervalo(v2,vConstruir2);
        
    }
    
    public Intervalo[] getIntervalos(){
        return this.vConstruir;
    }
    
    /**
     * retorna el recorrido
     * @param v los valores
     * @return recorridp
     */
    public double getRecorrido(double[] v) {
        int i;
        double max, min;
        max = 0;
        min = 1;
        for (i = 0; i < v.length - 1; i++) {
            if (v[i] > max)
                max = v[i];
            
            if (v[i] < min)
                min = v[i];          
        }
        setMaxvector(max);
        setMinvector(min);
        return (max - min);
    }
    
    
    public double getRecorridoDosVectores(double[] v1,double[] v2)
    {
        int i;
        double max, min,max2,min2;
        max = 0;
        min = 1;
        max2 = 0;
        min2 = 1;
        for (i = 0; i < v1.length - 1; i++) {
            if (v1[i] > max)
                max = v1[i];
            
            if (v1[i] < min)
                min = v1[i];          
        }
        
        for (i = 0; i < v2.length - 1; i++) {
            if (v2[i] > max2)
                max2 = v2[i];
            
            if (v2[i] < min2)
                min2 = v2[i];          
        }
        
        if (max>max2)
            setMaxvector(max);
        else
            setMaxvector(max2);
        if(min<min2)
            setMinvector(min);
        else
            setMinvector(min2);
        return (maxvector - minvector);
        
    }

    /**
     * contruye los intervalos
     * @param cantIntervalos cantidad de intervalos
     * @param v valores
     */
    public void construirIntervalos(int cantIntervalos, double[] v) {
        vConstruir = new Intervalo[cantIntervalos];
        int i;
        double anchoIntevalo;
        anchoIntevalo = getRecorrido(v) / cantIntervalos;
        for (i = 0; i < cantIntervalos; i++) {
            if (i == 0) {
                vConstruir[i] = new Intervalo(minvector, minvector + anchoIntevalo);
            } else {
                vConstruir[i] = new Intervalo(vConstruir[i - 1].getLsuperior(), vConstruir[i - 1].getLsuperior() + anchoIntevalo);
            }
        }
        this.completeIntervalo(vConstruir);
    }
    
    public void construirIntervalosDos(int cantIntervalos, double[] v,double[] v2) {
        vConstruir = new Intervalo[cantIntervalos];
        vConstruir2 = new Intervalo[cantIntervalos];
        int i;
        double anchoIntevalo;
        anchoIntevalo = getRecorridoDosVectores(v,v2) / cantIntervalos;
        for (i = 0; i < cantIntervalos; i++) {
            if (i == 0) {
                vConstruir[i] = new Intervalo(minvector, minvector + anchoIntevalo);
            } else {
                vConstruir[i] = new Intervalo(vConstruir[i - 1].getLsuperior(), vConstruir[i - 1].getLsuperior() + anchoIntevalo);
            }
        }
        
        for (i = 0; i < cantIntervalos; i++) {
            if (i == 0) {
                vConstruir2[i] = new Intervalo(minvector, minvector + anchoIntevalo);
            } else {
                vConstruir2[i] = new Intervalo(vConstruir2[i - 1].getLsuperior(), vConstruir2[i - 1].getLsuperior() + anchoIntevalo);
            }
        }
        this.completeIntervalo(vConstruir);
        this.completeIntervalo(vConstruir2);
    }

    //completa los intervalos con un intervalo vacios al comienzo y al final
    private void completeIntervalo(Intervalo[] vc) {
        Intervalo v[] = new Intervalo[vc.length + 2];
        for (int i = 1; i < v.length - 1; i++) {
            v[i] = vc[i - 1];
        }
        v[0] = new Intervalo();
        v[v.length - 1] = new Intervalo();
        v[0].setLsuperior(v[1].getLinferior());
        v[0].setLinferior(v[0].getLsuperior() - v[1].getAmplitud());
        v[v.length - 1].setLinferior(v[v.length - 2].getLsuperior());
        v[v.length - 1].setLsuperior(v[v.length - 1].getLinferior() + v[v.length - 1].getAmplitud());
        v[0].setMarcaClase();
        v[v.length - 1].setMarcaClase();
        vc = v;
    }

    // Controla los intervalos y setea la frecuencia de los valores dados en el vetor de dobles aleatorios
    private void setValoresIntervalo(double[] v, Intervalo[] intervalos) {
        int i, j;
        for (i = 0; i < v.length; i++) {
            for (j = 0; j < intervalos.length; j++) {
                if (intervalos[j].perteneceIntervalo(v[i])) {
                    intervalos[j].setFrecuencia();
                    break;
                }
            }
        }
    }

    /**
     * maximo del vector
     * @return el valor maximo que tiene el vector de doubles
     */
    private double getMaxvector() {
        return maxvector;
    }

    
    /**
     * setea el maximo del vector
     * @param maxvector maximo valor del vector
     */
    public void setMaxvector(double maxvector) {
        this.maxvector = maxvector;
    }
//
//    public double getMinvector() {
//        return minvector;
//    }
//
    /**
     * minimo valor del vector
     * @param minvector minimo valor del vector
     */
    public void setMinvector(double minvector) {
        this.minvector = minvector;
    }

    public Intervalo[] getVConstruir2() {
        return vConstruir2;
    }
}
