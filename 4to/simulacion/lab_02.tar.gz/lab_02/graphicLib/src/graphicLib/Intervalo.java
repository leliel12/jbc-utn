/**
 *  Ejes.java
 * 
 *  Copyright (C) - 2008 - JBCabral - JMGuzman - FAGambino
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


package graphicLib;

/**
 * representa intervalos
 * @author JBCabral - JMGuzman - FAGambino
 * @version 1.0
 */
class Intervalo {
   
    //variables
    private double linferior;
    private double lsuperior;
    private double marcaClase;
    private int frecuencia;
    private double amplitud;
    
    /** Creates a new instance of Intervalo */
    public Intervalo() {
    }

    /**
     * Creates a new instance of Intervalo
     * @param li limite superior
     * @param ls limite inferior
     */
    public Intervalo(double li, double ls) {
        setLinferior(li);
        setLsuperior(ls);
        setMarcaClase();
        setAmplitud(ls-li);
    }
   
    /**
     * obtiene el limite inferior
     * @return limite inferior
     */
    public double getLinferior() {
        return linferior;
    }

    /**
     * setea limite inferior
     * @param linferior
     */
    public void setLinferior(double linferior) {
        this.linferior = linferior;
    }

    /**
     * limite superior
     * @return setea limite superior
     */
    public double getLsuperior() {
        return lsuperior;
    }

    /**
     * setea limite superior
     * @param lsuperior setea limite superior
     * 
     */
    public void setLsuperior(double lsuperior) {
        this.lsuperior = lsuperior;
    }

    /**
     * retorna la marca de clase
     * @return marca de clase
     */
    public double getMarcaClase() {
        return marcaClase;
    }

    /**
     * genera la marca de clase
     */
    public void setMarcaClase() {
        this.marcaClase = (this.getLsuperior()+this.getLinferior())/2;
    }

    /**
     * retorna la frecuencia
     * @return frecuencia
     */
    public int getFrecuencia() {
        return frecuencia;
    }

    public void setFrecuencia() {
        this.frecuencia ++;
    }
    
    /**
     * si pertenece a este intervalo
     * @param valor
     * @return si pertenece o no
     */
    public boolean perteneceIntervalo(double valor){
        if (linferior>=valor || valor<lsuperior)
            return true;
        return false;
    }

    /**
     * retorna la amplitud
     * @return aplitud
     */
    public double getAmplitud() {
        return amplitud;
    }

    /**
     * setea la aplitud
     * @param amplitud aplitud
     */
    public void setAmplitud(double amplitud) {
        this.amplitud = amplitud;
    }
    
    
}
