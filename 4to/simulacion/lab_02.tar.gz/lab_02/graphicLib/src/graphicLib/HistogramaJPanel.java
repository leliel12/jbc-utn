/**
 *  HistogramaJPanel.java
 * 
 *  Copyright (C) - 2008 - JBCabral - JMGuzman - FAGambino
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package graphicLib;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.util.Random;
import javax.swing.JPanel;

/**
 * Genera un panel con el  potencial Histograma
 * @author JBCabral - JMGuzman - FAGambino
 * @version 1.0
 */
public class HistogramaJPanel extends javax.swing.JPanel {

    private Intervalo[] values;
    private Intervalo[] v2;
    private int cantIntervalos;
    private Ejes eje;
    private int cvad;

    /**
     * Genera un Panel que se usa para graficar el histograma
     * @param values Es el vector de dobles generados aleatoriamente
     * @param cantIntervalos Cantidad de intervalos que se generaran para el Histograma
     * @param labelX Inscripcion de la leyenda del eje X
     * @param labelY Inscripcion de la leyenda del eje Y
     * @param titulo Inscripcion del titulo del histograma
     * @return Devuelve el panel a usar para graficar
     */
    public static JPanel getHistogramaJPanel(double[] values, int cantIntervalos, String labelX, String labelY, String titulo, float porc) throws InvalidPorcException {
        IntervalGenerator g = new IntervalGenerator(values, cantIntervalos);
        Intervalo[] ivl = g.getIntervalos();
        int n = values.length;
        return new HistogramaJPanel(ivl, cantIntervalos, labelX, labelY, titulo, porc, n);
    }

    public static JPanel getHistogramaJPanel(double[] values, double[] v2, int cantIntervalos, String labelX, String labelY, String titulo, float porc) throws InvalidPorcException {
        IntervalGenerator g = new IntervalGenerator(values, v2, cantIntervalos);
        //  IntervalGenerator g1 = new IntervalGenerator(v2,cantIntervalos);
        Intervalo[] ivl = g.getIntervalos();
        Intervalo[] ivl2 = g.getVConstruir2();
        int n = values.length;
        return new HistogramaJPanel(ivl, ivl2, cantIntervalos, labelX, labelY, titulo, porc, n);
    }

    /**
     * Creates new form HistogramaJPanel
     * @param values vector de Intervalos a construir
     * @param cantIntervalos Cantidad de intervalos que se generaran para el Histograma
     * @param labelX Inscripcion de la leyenda del eje X
     * @param labelY Inscripcion de la leyenda del eje Y
     * @param titulo Inscripcion del titulo del histograma
     */
    public HistogramaJPanel(Intervalo[] values, int cantIntervalos, String labelX, String labelY, String titulo, float porc, int n) throws InvalidPorcException {
        initComponents();

        this.values = values;
        this.setCantToDraw(porc, n);
        this.lblX.setText(labelX);
        this.lblY.setText(labelY);
        this.cantIntervalos = cantIntervalos;
        this.lblTitulo.setText(titulo);

    }

    private HistogramaJPanel(Intervalo[] values, Intervalo[] v2, int cantIntervalos, String labelX, String labelY, String titulo, float porc, int n) throws InvalidPorcException {
        initComponents();

        this.values = values;
        this.setCantToDraw(porc, n);
        this.v2 = v2;
        this.lblX.setText(labelX);
        this.lblY.setText(labelY);
        this.cantIntervalos = cantIntervalos;
        this.lblTitulo.setText(titulo);

    }

    /**
     * Redefinicion del metodo de awt para repintar el Panel
     * @param g Componente de tipo Graphics en el que se dibuja
     */
    @Override
    public void paintComponent(Graphics g) {
        pintarEjes(g);
        // pintarHistograma(g);
        pintarLeyendas(g);
        pintarHistogramaDoble(g);
    }

    /**
     * Dibuja efectivamente el Histograma, leyendas de intervalos y frecuencias
     * @param g Componente de tipo Graphics en el que se dibuja
     */
    public void pintarHistograma(Graphics g) {
        int separacionX = 0;
        int anchoBarra = 0;
        int desp = 0;
        int cont = 0;
        separacionX = (int) ((eje.getLargoEjeX() - 30) / (cantIntervalos + 2)); //-30 para dejar espacio de barra
        //+2 por la ampliacion de intervalos (uno al comienzo y otro al final)
        anchoBarra = (int) (0.3 * separacionX);  //un 30% de la separacion a partir de la marca de clase       

        int maxFrec = obtenerMaximaFrecuenciaSerie();
        int frecuencia = 0;

        for (int i = 0; i < values.length; i++) {
            frecuencia = (values[i].getFrecuencia() * eje.getLargoEjeY()) / maxFrec; //calculo la altura de acuerdo a la escala dada por la maxima frec.
            desp = i + 1; //desplazamiento

            Color c = new Color(new Random().nextInt(256), new Random().nextInt(256), new Random().nextInt(256)); //setea el color de las barras   
            g.setColor(c);
            g.fill3DRect(separacionX * desp, eje.getOrigenY() - frecuencia, anchoBarra, frecuencia, true);//dibuja los rectangulos
            g.setColor(Color.BLACK);
            g.drawString(String.valueOf(Util.truncateDouble(values[i].getMarcaClase(), 4)), (separacionX * desp) - 10, eje.getOrigenY() + 15);
            g.drawString(String.valueOf(values[i].getFrecuencia()), (separacionX * desp), eje.getOrigenY() - frecuencia - 7);
            cont += values[i].getFrecuencia();
            if (cont >= this.cvad) {
                i = values.length;
            }
        }

    }

    /**
     * Redefinicion de pintar histograma para permitir dos pintados juntos
     * @param g
     */
    public void pintarHistogramaDoble(Graphics g) {
        int separacionX = 0;
        int anchoBarra = 0;
        int desp = 0;
        separacionX = (int) ((eje.getLargoEjeX() - 30) / (cantIntervalos + 2)); //-30 para dejar espacio de barra
        //+2 por la ampliacion de intervalos (uno al comienzo y otro al final)

        anchoBarra = (int) (0.3 * separacionX);  //un 30% de la separacion a partir de la marca de clase        
        int maxFrec = obtenerMaximaFrecuenciaDosSeries();
        int frecuencia = 0;
        int frecuencia2 = 0;
        int cont = 0;
        for (int i = 0; i < values.length; i++) //da lo mismo si es un vector u otro, ambos deber�an los mismos tama�os
        {
            frecuencia = (values[i].getFrecuencia() * eje.getLargoEjeY()) / maxFrec; //calculo la altura de acuerdo a la escala dada por la maxima frec.
            frecuencia2 = (v2[i].getFrecuencia() * eje.getLargoEjeY()) / maxFrec; //calculo la altura de acuerdo a la escala dada por la maxima frec.          
            desp = i + 1; //desplazamiento
            ;

            g.setColor(Color.RED);
            g.fill3DRect(separacionX * desp, eje.getOrigenY() - frecuencia, anchoBarra, frecuencia, true);//dibuja los rectangulos

            g.setColor(Color.BLUE);
            g.fill3DRect((separacionX * desp) + anchoBarra, eje.getOrigenY() - frecuencia2, anchoBarra, frecuencia2, true);

            g.setColor(Color.BLACK);

            //leyendas primera serie
            g.drawString(String.valueOf(Util.truncateDouble(values[i].getMarcaClase(), 2)), (separacionX * desp) - 15, eje.getOrigenY() + 15);
            g.drawString(String.valueOf(values[i].getFrecuencia()), (separacionX * desp), eje.getOrigenY() - frecuencia - 7);
            //leyendas segunda serie    
            g.drawString(String.valueOf(v2[i].getFrecuencia()), (separacionX * desp) + anchoBarra, eje.getOrigenY() - frecuencia2 - 7);
            cont += values[i].getFrecuencia();
            if (cont >= this.cvad) {
                i = values.length;
            }
        }
    }

    /**
     * Dibuja los ejes cartesianos del grafico
     * @param g Componente de tipo Graphics en el que se dibuja
     */
    private void pintarEjes(Graphics g) {
        Dimension area;
        area = this.getSize();
        g.drawLine(20, 40, 20, area.height - 80);  //eje y 
        g.drawLine(20, area.height - 80, area.width - 50, area.height - 80);  //eje x         
        eje = new Ejes(area.width - 70, area.height - 120, 20, area.height - 80);
    }

    private void pintarLeyendas(Graphics g) {
        Dimension area;
        Dimension rectangulo = new Dimension();
        rectangulo.setSize(30, 20);
        area = this.getSize();

        g.setColor(Color.RED);
        g.fill3DRect(30, area.height - 40, (int) rectangulo.getWidth(), (int) rectangulo.getHeight(), true);
        g.setColor(Color.BLUE);
        g.fill3DRect(200, area.height - 40, (int) rectangulo.getWidth(), (int) rectangulo.getHeight(), true);
        g.setColor(Color.BLACK);
        g.drawString("Datos observados", 65, area.height - 20);
        g.drawString("Datos generados", 235, area.height - 20);
    }
    // obtiene la mayor frecuencia de la serie para usar en escalacion
    private int obtenerMaximaFrecuenciaSerie() {
        int maxFrec = 0;
        for (int i = 0; i < this.values.length; i++) {
            if (maxFrec < this.values[i].getFrecuencia()) {
                maxFrec = this.values[i].getFrecuencia();
            }
        }
        return maxFrec;
    }

    private int obtenerMaximaFrecuenciaDosSeries() {
        int maxFrec = 0;
        int maxFrec2 = 0;
        for (int i = 0; i < this.values.length; i++) {
            if (maxFrec < this.values[i].getFrecuencia()) {
                maxFrec = this.values[i].getFrecuencia();
            }
        }
        for (int i = 0; i < this.v2.length; i++) {
            if (maxFrec2 < this.v2[i].getFrecuencia()) {
                maxFrec2 = this.v2[i].getFrecuencia();
            }
        }
        if (maxFrec > maxFrec2) {
            return maxFrec;
        } else {
            return maxFrec2;
        }
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        lblX = new javax.swing.JLabel();
        lblY = new javax.swing.JLabel();
        lblTitulo = new javax.swing.JLabel();

        lblX.setFont(new java.awt.Font("Tahoma", 1, 11));
        lblX.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblX.setText("x");

        lblY.setFont(new java.awt.Font("Tahoma", 1, 11));
        lblY.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblY.setText("y");
        lblY.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        lblTitulo.setFont(new java.awt.Font("Tahoma", 1, 14));
        lblTitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitulo.setText("Titulo");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblY)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTitulo, javax.swing.GroupLayout.DEFAULT_SIZE, 367, Short.MAX_VALUE)
                    .addComponent(lblX, javax.swing.GroupLayout.DEFAULT_SIZE, 367, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblY, javax.swing.GroupLayout.DEFAULT_SIZE, 291, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblTitulo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 260, Short.MAX_VALUE)
                        .addComponent(lblX)))
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JLabel lblX;
    private javax.swing.JLabel lblY;
    // End of variables declaration//GEN-END:variables
    /**
     * Devuelve la cantidad de intervalos de la serie
     * @return retorna cantidad de intervalos
     */
    public int getCantIntervalos() {
        return cantIntervalos;
    }

    /**
     * Escribe la cantidad de intervalos 
     * @param cantIntervalos la cantidad de intervalos a escribir
     */
    public void setCantIntervalos(int cantIntervalos) {
        this.cantIntervalos = cantIntervalos;
    }

    private void setCantToDraw(float porc, int n) throws InvalidPorcException {
        if (porc < 0 || porc > 1) {
            throw new InvalidPorcException();
        }
        this.cvad = (int) (porc * n);
        System.out.println("Porcentaje calculado a " + String.valueOf(cvad));
    }
}
