/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphicLib;

/**
 *
 * @author juan
 */
public class InvalidPorcException extends Exception {

    /**
     * Creates a new instance of <code>InvalidPorcException</code> without detail message.
     */
    public InvalidPorcException(float r) {
        this(String.valueOf(r)+ " no esta entre 0 y 1");
    }


    /**
     * Constructs an instance of <code>InvalidPorcException</code> with the specified detail message.
     * @param msg the detail message.
     */
    public InvalidPorcException(String msg) {
        super(msg);
    }

    InvalidPorcException() {
        throw new UnsupportedOperationException("Not yet implemented");
    }
}
