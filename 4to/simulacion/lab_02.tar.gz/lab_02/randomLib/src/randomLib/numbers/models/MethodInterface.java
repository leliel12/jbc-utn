/**
 *  MethodInterface.java
 * 
 *  Copyright (C) - 2008 - juan b cabral
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package randomLib.numbers.models;
import randomLib.numbers.exceptions.InsuficientDigitsException;


/**
 * metods a redefinir por los metodos de psudo-random
 * @author JuanBC - JuanMG - FranciscoAG
 * @version 1.1
 */
public interface MethodInterface {

    /**
     * formula del metodo
     * @param value0
     * @param value1
     * @return resultado
     */
    public long formula(long value0, long value1);
    
    
    /**
     * genera un nuevo numero random
     * @return nuevo numero random long
     * @throws simRandom.exceptions.InsuficientDigitsException
     */
    public long getNextLong() throws InsuficientDigitsException;
    
    /**
     * genera un nuevo numero random de tipo double entre 0 y 1
     * @return un nuevo numero random
     * @throws simRandom.exceptions.InsuficientDigitsException
     */
    public double getNextDouble() throws InsuficientDigitsException;
    
    
}
