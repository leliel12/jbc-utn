/**
 *  MultDeCongruencia.java
 * 
 *  Copyright (C) - 2008 - juan b cabral
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package randomLib.numbers;


import randomLib.numbers.exceptions.InsuficientDigitsException;
import randomLib.numbers.exceptions.InvalidDoubleSeedsException;
import randomLib.numbers.models.Method;
import randomLib.numbers.util.Common;


/**
 * Genera numeros al azar dado el metdo de congruencia
 * 
 * el constructor recibe por parametros una semillas y dos constantes k y a
 * la  semilla se almacena en la instancia de la superclase
 * el constructor asigna el valor de la semilla en la variable value (value de la superclase)
 * A cada iteracion se asigna el nuevo valor en value
 * @author JuanBC - JuanMG - FranciscoAG
 * @version 1.0
 */
public class MultDeCongruencia extends Method{

    // constante a
    private int a;
    // constante k
    private int k;

    /**
     * crea una nueva instancia de la clase
     * @param seed semilla
     * @param a constante a
     * @param k constante k
     */
    public MultDeCongruencia(long seed, int a, int k) {
        super(seed);
        this.a = a;
        this.k = k;
    }
    
    /**
     * crea una nueva instancia de la clase
     * reibe la semilla como double y la almacena internamente como long
     * @param seed semilla
     * @param a constante a
     * @param k constante k
     */
    public MultDeCongruencia(double seed, int a, int k) throws InvalidDoubleSeedsException {
        super(seed);
        this.a = a;
        this.k = k;
    }

    /**
     * evalua segun la formula dle metodo
     * @param value0 valor
     * @param value1 no se usa
     * @return evaluacion de la formula
     */
    @Override
    public long formula(long value0, long value1) {
        return (getA() * value0) % getK();
    }

    /**
     * retorna un nuevo valor de la iteracion del metodo
     * @return valor de la iteracion del metodo
     * @throws simRandom.exceptions.InsuficientDigitsException
     */
    @Override
    public long getNextLong() throws InsuficientDigitsException {
        long value = super.getValue();
        value = this.formula(value, 0);
        super.setValue(value);
        return super.getValue();
    }

    /**
     * valor de la constante a
     * @return valor de la constante a
     */
    public int getA() {
        return a;
    }

    /**
     * valor de la constante k
     * @return valor de la constante k
     */
    public int getK() {
        return k;
    }

    /**
     * genera un nuevo numero random de tipo double entre 0 y 1
     * @return un nuevo random
     * @throws simRandom.exceptions.InsuficientDigitsException
     */
    @Override
    public double getNextDouble() throws InsuficientDigitsException {
        double aux = Common.long2Double(this.getNextLong());
        return aux;
    }
   
}
