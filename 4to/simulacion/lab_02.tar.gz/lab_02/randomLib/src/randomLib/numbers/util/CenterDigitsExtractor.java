/**
 *  CenterDigitsExtractor.java
 * 
 *  Copyright (C) - 2008 - juan b cabral
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package randomLib.numbers.util;

import randomLib.numbers.exceptions.InsuficientDigitsException;

/**
 * clase que se encarga de reciir un long por parametro y extraer sus n digitos
 * centrales
 * @author JuanBC
 * @version 1.0
 */
public abstract class CenterDigitsExtractor {

    
     // por comodidad copian las contantes de BalanceConstants
    private static final int LEFT = BalanceConstants.LEFT;
    private static final int RIGHT = BalanceConstants.RIGHT;

    /**
     * retorna los <code>digitsToget</code> digitos centrales, de <code>value</code>
     * seleccionado un <code>valance</code> izquierdo o derecho y nunca excediendose en digitos de
     * <code>totalDigits</code>
     * @param value
     * @param digitsToGet
     * @param totalDigits
     * @param balance
     * @return digit
     * @throws simRandom.exceptions.InsuficientDigitsException
     */
    public static long getDigits(long value, int digitsToGet, int totalDigits, int balance) throws InsuficientDigitsException {
        if (digitsToGet > totalDigits) {
            throw new InsuficientDigitsException();
        } else {
            String str = String.valueOf(value);
            str = complete(str, totalDigits);
            str = select(str, digitsToGet, balance);
            str=str.replaceFirst("-", "");
            return Long.parseLong(str);
        }

    }

    // selenciona los caracteres centrales de una cadena 
    private static String select(String str, int digitsToGet, int valance) {
        while (str.length() > digitsToGet) {
            switch (valance) {
                case LEFT:
                    str = deleteCharAt(str, str.length() - 1);
                    valance = RIGHT;
                    break;
                case RIGHT:
                    str = deleteCharAt(str, 0);
                    valance = LEFT;
                    break;
            }
        }
        return str;
    }

    // elimina un caracter en una cadena en particular
    private static String deleteCharAt(String str, int index) {
        String aux = "";
        for (int i = 0; i < str.length(); i++) {
            if (i != index) {
                aux = aux + str.charAt(i);
            }
        }
        return aux;
    }

    //completa una cadena hasta que tenga tantos caracteres como total digits
    private static String complete(String str, int totalDigits) {
        while (str.length() < totalDigits) {
            str = "0" + str;
        }
        return str;
    }
}
