/**
 *  Method.java
 * 
 *  Copyright (C) - 2008 - juan b cabral
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
package randomLib.numbers.models;

import randomLib.numbers.exceptions.InvalidDoubleSeedsException;
import randomLib.numbers.util.Common;


/**
 * Metodos y atributos comunes que poseen los metodos de pseudo-random
 * @author JuanBC - JuanMG - FranciscoAG
 * @version 1.0
 */
public abstract class Method implements MethodInterface{

    /**
     * semilla original
     */
    private long seed;
    /**
     * valor actual del calculo
     */
    long value;
   
    /**
     * cuantas veces saque un random de aca
     */
    private int iteration;
    
    /**
     * crea una nueva instancia de la clase
     * @param seed
     */
    public Method(long seed) {
        this.seed = seed;
        this.value = seed;
        this.iteration=0;
    }
    
    /**
     * crea una nueva instancia de la clase recibiendo por parametro un double
     * pero almacenandolo internamente como un long
     * @param seed
     */
    public Method(double seed) throws InvalidDoubleSeedsException{
        if(seed <= 0 || seed >= 1) throw new InvalidDoubleSeedsException();
        this.seed = Common.double2Long(seed);
        this.value = this.seed;
    }

      
    /**
     * valor de la semilla original
     * @return seed
     */
    public long getSeed() {
        return seed;
    }

  
    /**
     * retorna el ultimo valor obtenido
     * @return value
     */
    public long getValue() {
        return value;
    }
    
    /**
     * carga un valor - este metodo sera deprecado en todas las clases heredadas
     * @param value
     */
    protected void setValue(long value) {
        this.value = value;
    }
    
    

    /**
     * cantidad de numeros generados por el metodo
     * @return iteracion
     */
    public int getIteration() {
        return iteration;
    }

    
    
}
