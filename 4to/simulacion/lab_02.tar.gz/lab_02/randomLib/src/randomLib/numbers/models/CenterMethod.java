/**
 *  Method.java
 * 
 *  Copyright (C) - 2008 - juan b cabral
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
package randomLib.numbers.models;

import randomLib.numbers.exceptions.InvalidDoubleSeedsException;
import randomLib.numbers.util.Common;

/**
 * Metodos y atributos comunes que poseen los metodos de pseudo-random de seleccion central
 * @author JuanBC - JuanMG - FranciscoAG
 * @version 1.0
 */
public abstract class CenterMethod  extends Method implements CenterMethodInterface{

   
    /**
     * indica si se tomaran mas digitos de la izquierda o la derecha en metodos
     * que implique la extraccion de digitos centrales
     */
    private int balance;
    
 
    /**
     * cantidad maxima que puede brindar esta semilla
     */
    private int totalDigits;

    /**
     * crea una nueva instancia de la clase recibiendo por parametro un double
     * pero almacenandolo internamente como un long
     * @param seed semilla 
     * @param balance valance izquierdo o derecho
     */
    public CenterMethod(double seed, int balance) throws InvalidDoubleSeedsException {
        super(seed);
        this.balance=balance;
    }
    
    /**
     * crea una nueva instancia de la clase
     * @param seed semilla 
     * @param balance valance izquierdo o derecho
     */
    public CenterMethod(long seed, int balance) {
        super(seed);
        this.balance=balance;
    }
    
 
    /**
     * el balance de la formula que puede ser 1 izquierda, 2 derecha o -1 en metodos en el 
     * cual no sea necesario
     * todos los valores estan definidos en simRandom.util.ValanceConstants
     * @return balance
     */
    public int getBalance() {
        return balance;
    }



    /**
     * retorna el valor maximo de digitos que puede generar esta semilla
     * @return totalDigits
     */
    public int getTotalDigits() {
        return totalDigits;
    }

    /**
     * ingresa el valor maximo de digitos que puede generar esta semilla
     * debe ser calculado en las clases heredadas con su formula respectiva
     * y ingresado a esta super-clase
     * @param totalDigits
     */
    public void setTotalDigits(int totalDigits) {
        this.totalDigits = totalDigits;
    }

    /**
     * cantidad de digitos que posee la semilla original
     * y se supone que uno pretende generar
     * @return cantidaddedigitos
     */
    public int digitToGet() {
        long seed=super.getSeed();
        return Common.getNumberOfDigits(seed);
    }
}
