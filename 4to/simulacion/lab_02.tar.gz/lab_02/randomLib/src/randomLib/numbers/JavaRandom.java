/**
 *  CongMixta.java
 * 
 *  Copyright (C) - 2008 - juan b cabral
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package randomLib.numbers;

import java.util.Random;
import randomLib.numbers.exceptions.InsuficientDigitsException;
import randomLib.numbers.exceptions.InvalidDoubleSeedsException;
import randomLib.numbers.models.Method;
import randomLib.numbers.util.Common;





/**
 * implementacion del random de java utilizando este protocolo
 * 
 * @author JuanBC - JuanMG - FranciscoAG
 * @version 1.0
 */
public class JavaRandom extends Method {

   private Random r;

    /**
     * crea una nueva instancia de la clase
     * @param seed semilla
     */
    public JavaRandom(long seed) {
        super(seed);
        r=new Random(super.getSeed());
    }

    /**
     * crea una nueva instancia de la clase recibe la semilla como double y la almacena como long
     * @param seed semilla
     */
    public JavaRandom(double seed) throws InvalidDoubleSeedsException {
        super(seed);
        r=new Random(super.getSeed());
    }
    
    /**
     * casi no sirve de nada
     * @param value0 - no se usa
     * @param value1 - no se usa
     * @return valor de la evaluación
     */
    @Override
    public long formula(long value0, long value1) {
        long aux=0;
        do{
            aux = r.nextLong();
        }while(aux<0);
        return aux;
    }

    /**
     * retorna un nuevo valor de la iteracion del metodo
     * @return valor de la iteracion del metodo
     * @throws simRandom.exceptions.InsuficientDigitsException
     */
    @Override
    public long getNextLong() throws InsuficientDigitsException {
        super.setValue(this.formula(-1, -1));
        return super.getValue();
    }

    
    /**
     * genera un nuevo numero random de tipo double entre 0 y 1
     * @return random de tipo double entre 0 y 1;
     * @throws simRandom.exceptions.InsuficientDigitsException
     */
    @Override
    public double getNextDouble() throws InsuficientDigitsException {
        double aux = Common.long2Double(this.getNextLong());
        return aux;
    }
}
