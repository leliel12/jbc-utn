/*
 *  Gamma.java 
 * 
 *  Copyright (C) - 2008 - Juanbc
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
package randomLib.variables;

import randomLib.numbers.exceptions.InsuficientDigitsException;
import randomLib.numbers.models.Method;
import randomLib.variables.models.Distribution;

/**
 * calculo de variables por Gamma
 * @author JuanBC - JuanMG - FranciscoAG
 * @version 1.0
 */
public class Gamma<E extends Method> extends Distribution {

    //lambda
    private double lamb;
    //recorrido
    private double k;
    private double fkmu;

    /**
     * crea una nueva instancia de la clase
     * @param randomizer calculador de numeros aleatorios
     * @param lambda valor de lambda
     */
    public Gamma(E randomizer, double lambda, double recorrido) {
        super(randomizer);
        this.lamb = lambda;
        this.k = recorrido;
        this.fkmu = this.factorial(recorrido);
    }

    /**
     * un valor mas dentro de la distribucion
     * @return un nuevo valor
     */
    public double getNextDouble() {
        double x=0;
        try {
            x = super.getRand().getNextDouble();
        } catch (InsuficientDigitsException ex) {
        }
        
        double a1 = Math.pow(this.lamb, (-1)*this.k);
        double a2 = Math.pow(x, k - 1);
        double a3= Math.exp(-1*(x/this.lamb));
        
        return ((a1*a2*a3)/this.fkmu);
    }

    /**
     * para que retorne <code>c</code> valores
     * @param c cantidad de valores
     * @return vector con todos los valores
     */
    public double[] getDoubles(int c) {
        double[] a=new double[c];
        for(int i=0;i<c;i++){
            a[i]=this.getNextDouble();
        }
        return a;
    }

    private double factorial(double k) {
        if ((int)k != 0) {
            return k * factorial(k - 1);
        }
        return 1;
    }

    /**
     * para obtener el parametro lambda
     * @return lambda
     */
    public double getLambda() {
        return lamb;
    }

    /**
     * retorna parametro k
     * @return k
     */
    public double getK() {
        return k;
    }
}
