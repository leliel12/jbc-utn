/*
 *  Poisson.java 
 * 
 *  Copyright (C) - 2008 - Juanbc
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
package randomLib.variables;

import java.util.logging.Level;
import java.util.logging.Logger;
import randomLib.numbers.exceptions.InsuficientDigitsException;
import randomLib.numbers.models.Method;
import randomLib.variables.models.Distribution;

/**
 * generador de variables aleatorias en distribucion poisson
 * @author JuanBC - JuanMG - FranciscoAG
 * @version 1.0
 */
public class Poisson<E extends Method> extends Distribution {

    //generador de variables aleatorias uniforme
    private Unif unif;
    //lambda
    private double lambda;
    
    /**
     * crea una nueva instancia de la clase
     * @param randomizer generador de numeros aleatorios
     * @param lambda valor de lambda
     */
    public Poisson(E randomizer, double lambda) {
        super(randomizer);
        unif = new Unif(randomizer, 0, 1);
        this.lambda = lambda;
    }

    /**
     * un nuevo valor dentro de la distribucion
     * @return valor dentro de la distribucion
     */
    public double getNextDouble() {
        double k = 1;
        double x = 1;
        double e = Math.exp(-lambda);
        boolean nocumple = true;
        while (nocumple) {
            try {
                k = k * unif.getNextDouble();
                if (k < e) {
                    nocumple = false;
                } else {
                    x++;
                }
            } catch (Exception ex) {
                Logger.getLogger(Poisson.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        super.add(x);
        return x ;
    }

    /**
     * para que retorne <code>c</code> valores
     * @param c cantidad de valores
     * @return vector con todos los valores
     */
    public double[] getDoubles(int c) {
        double[] a = new double[c];
        for (int i = 0; i < c; i++) {
            a[i] = this.getNextDouble();
        }
        return a;
    }
}
