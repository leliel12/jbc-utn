/**
 *  ProdMedio.java
 * 
 *  Copyright (C) - 2008 - juan b cabral
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package randomLib.numbers;


import randomLib.numbers.exceptions.DiferentSizesOfSeedsException;
import randomLib.numbers.exceptions.InsuficientDigitsException;
import randomLib.numbers.exceptions.InvalidDoubleSeedsException;
import randomLib.numbers.models.CenterMethod;
import randomLib.numbers.util.CenterDigitsExtractor;
import randomLib.numbers.util.Common;


/**
 * Genera numeros al azar dado el metdo de producto medio
 * 
 * el constructor recibe por parametros 2 semillas y el valance
 * la primer semilla se almacena en la instancia de la superclase y es llamada semilla0 o seed0
 * la segunda semilla es guardada en la instancia de esta clase.
 * el constructor asigna estos valores de las semillas en las variables value 0(value de la superclase)
 * y value1(asignado aqui) y opera sobre estos dos.
 * A cada iteracion se copia el contenido de value1 en value0 y se recalcula value1
 * 
 * @author JuanBC - JuanMG - FranciscoAG
 * @version 1.0
 */
public class ProdMedio extends CenterMethod {

    //semilla 1
    private long seed1;
    //valor 1
    private long value1;

    /**
     * crea nueva instancia de la clase
     * @param seed0 primer semilla
     * @param seed1 semilla 1
     * @param balance balance
     * @throws simRandom.exceptions.DiferentSizesOfSeedsException
     */
    public ProdMedio(long seed0, long seed1, int balance) throws DiferentSizesOfSeedsException {
        super(seed0, balance);
        if (Common.getNumberOfDigits(seed0) != Common.getNumberOfDigits(seed1)) {
            throw new DiferentSizesOfSeedsException();
        } else {
            this.seed1 = seed1;
            this.value1 = seed1;
        }
        this.setTotalDigits();
    }

    /**
     * crea nueva instancia de la clase
     * @param seed0 primer semilla
     * @param seed1 semilla 1
     * @param balance balance
     * @throws simRandom.exceptions.DiferentSizesOfSeedsException
     */
    public ProdMedio(double seed0, double seed1, int balance) throws DiferentSizesOfSeedsException, InvalidDoubleSeedsException {
        super(seed0, balance);
        if (seed1 >= 1 || seed1 <= 0) {
            throw new InvalidDoubleSeedsException();
        } else {
            if (Common.getNumberOfDigits(super.getSeed()) != Common.getNumberOfDigits(Common.double2Long(seed1))) {
                throw new DiferentSizesOfSeedsException();
            } else {
                this.seed1 = Common.double2Long(seed1);
                this.value1 = this.seed1;
            }
        }
        this.setTotalDigits();
    }

    /**
     * calculo de la formula de congruente aditivo
     * @param value0
     * @param value1
     * @return valor de la evaluación
     */
    @Override
    public long formula(long value0, long value1) {
        return value0 * value1;
    }

    /**
     * retorna un nuevo valor de la iteracion del metodo
     * @return valor de la iteracion del metodo
     * @throws simRandom.exceptions.InsuficientDigitsException
     */
    @Override
    public long getNextLong() throws InsuficientDigitsException {
        long val0 = super.getValue();
        long val1 = this.getValue1();
        super.setValue(val1);
        val1 = this.formula(val0, val1);
        val1 = CenterDigitsExtractor.getDigits(val1, super.digitToGet(), super.getTotalDigits(), super.getBalance());
        this.value1 = val1;
        return this.getValue1();
    }

    /**
     * carga el valor maximo de digitos que se puede obtener con esta semilla
     */
    @Override
    public void setTotalDigits() {
        long snod = Common.sameDigitsNine(super.getSeed());
        snod = this.formula(snod, snod);
        super.setTotalDigits(Common.getNumberOfDigits(snod));
    }

    /**
     * valor de la semilla1
     * @return valor de la semilla 1
     */
    public long getSeed1() {
        return seed1;
    }

    /**
     * valor de la iteracion n
     * @return valor de la iteracion n
     */
    public long getValue1() {
        return value1;
    }

    /**
     * valor de la semilla0
     * @return valor de la semilla 0
     */
    @Override
    public long getSeed() {
        return super.getSeed();
    }

    /**
     * retorna valor0
     * @return valor de la iteracion n-1
     */
    @Override
    public long getValue() {
        return super.getValue();
    }

    /**
     * setea los valores de la iteracion n-1
     * @param value valor de la iteracion n-1
     */
    @Override
    public void setValue(long value) {
        super.setValue(value);
    }

    /**
     * setea los valores de la iteracion n-1
     * @param value valor de la iteracion n-1
     */
    public void setValue1(long value) {
        this.value1 = value;
    }

    /**
     * genera un nuevo numero random de tipo double entre 0 y 1
     * @return un nuevo random
     * @throws simRandom.exceptions.InsuficientDigitsException
     */
    @Override
    public double getNextDouble() throws InsuficientDigitsException {
        double aux = Common.long2Double(this.getNextLong());
        return aux;
    }
}
