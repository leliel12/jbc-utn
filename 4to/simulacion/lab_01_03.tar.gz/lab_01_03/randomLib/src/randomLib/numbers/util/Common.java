/**
 *  Commmon.java
 * 
 *  Copyright (C) - 2008 - juan b cabral
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package randomLib.numbers.util;

/**
 * utilidades simples
 * @author JuanBC
 * @version 1.0
 */
public abstract class Common {

    /**
     * dado un <code>calue</code> ingresado retorna un valor
     * con la misma cantidad de digitos pero solo con numeros 9
     * @param value
     * @return numeor con la misma cantidad de digitos que value pero solo con numeros 9
     */
    public static long sameDigitsNine(long value) {
        char[] c = String.valueOf(value).toCharArray();
        for (int i = 0; i < c.length; i++) {
            c[i] = '9';
        }
        return Long.parseLong(String.valueOf(c));
    }

    /**
     * retorna la cantidad de digitos de un valor
     * @param value
     * @return cantida de digitos de un valor
     */
    public static int getNumberOfDigits(long value) {
        return String.valueOf(value).length();
    }

    /**
     * recibe un double por parametro y devuelve un long de su parte fraccionaria
     * @param value valor double
     * @return parte fraccionaria del double en long
     */
    public static long double2Long(Double value) {
        String aux = String.valueOf(value);
        aux=aux.replace("-","");
        aux=aux.toLowerCase().replace("e","");
        aux = aux.substring(aux.indexOf(".") + 1, aux.length());
        return Long.parseLong(aux);
    }
    
    /**
     * recibe un long por parametro y devuelve un long
     * @param value valor long
     * @return double que tiene al long como parte fracionaria
     */
    public static double long2Double(long value) {
        String aux=String.valueOf(value);
        aux=aux.replace("-","");
        aux=aux.toLowerCase().replace("e","");
        aux="0." + aux;
        return Double.parseDouble(aux);
    }
}
