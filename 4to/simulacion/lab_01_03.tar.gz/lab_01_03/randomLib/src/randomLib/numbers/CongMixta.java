/**
 *  CongMixta.java
 * 
 *  Copyright (C) - 2008 - juan b cabral
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package randomLib.numbers;

import randomLib.numbers.exceptions.InsuficientDigitsException;
import randomLib.numbers.exceptions.InvalidDoubleSeedsException;
import randomLib.numbers.models.Method;
import randomLib.numbers.util.Common;



/**
 * Genera numeros al azar dado el metdo de congruenia mixta
 * 
 * el constructor recibe por parametros una semillas y constantes a, k y c
 * la primer semilla se almacena en la instancia de la superclase y es llamada semilla0 o seed0
 * el constructor asigna el valor de la semilla en la variable value (value de la superclase)
 * opera sobre esta.
 * a cada iteracion el nuevo valor es almacenado nuevamente en la variable value
 * 
 * @author JuanBC - JuanMG - FranciscoAG
 * @version 1.0
 */
public class CongMixta extends Method {

    // constante a
    private int a;
    // constante k
    private int k;
    // constante c
    private int c;

    /**
     * crea una nueva instancia de la clase
     * @param seed semilla
     * @param a constante a
     * @param k constante k
     * @param c constante c
     */
    public CongMixta(long seed, int a, int k, int c) {
        super(seed);
        this.a = a;
        this.k = k;
        this.c = c;
    }

    /**
     * crea una nueva instancia de la clase recibe la semilla como double y la almacena como long
     * @param seed semilla
     * @param a constante a
     * @param k constante k
     * @param c constante c
     */
    public CongMixta(double seed, int a, int k, int c) throws InvalidDoubleSeedsException {
        super(seed);
        this.a = a;
        this.k = k;
        this.c = c;
    }
    
    /**
     * calculo de la formula de congruencia mixta
     * @param value0
     * @param value1 - no se usa
     * @return valor de la evaluación
     */
    @Override
    public long formula(long value0, long value1) {
        return (getA() * value0 + getC()) % getK();
    }

    /**
     * retorna un nuevo valor de la iteracion del metodo
     * @return valor de la iteracion del metodo
     * @throws simRandom.exceptions.InsuficientDigitsException
     */
    @Override
    public long getNextLong() throws InsuficientDigitsException {
        long value = super.getValue();
        value = this.formula(value, 0);
        super.setValue(value);
        return super.getValue();
    }

    /**
     * retorna el valor de la constante A
     * @return valor de la constante A
     */
    public int getA() {
        return a;
    }

    /**
     * retorna el valor de la constante K
     * @return valor de la constante K
     */
    public int getK() {
        return k;
    }

    /**
     * retorna el valor de la constante C
     * @return valor de la constante C
     */
    public int getC() {
        return c;
    }

    /**
     * genera un nuevo numero random de tipo double entre 0 y 1
     * @return un nuevo random
     * @throws simRandom.exceptions.InsuficientDigitsException
     */
    @Override
    public double getNextDouble() throws InsuficientDigitsException {
        double aux = Common.long2Double(this.getNextLong());
        return aux;
    }
}
