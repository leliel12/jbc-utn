/**
 *  ProdMedioModificado.java
 * 
 *  Copyright (C) - 2008 - juan b cabral
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package randomLib.numbers;


import randomLib.numbers.exceptions.InsuficientDigitsException;
import randomLib.numbers.exceptions.InvalidDoubleSeedsException;
import randomLib.numbers.models.CenterMethod;
import randomLib.numbers.util.CenterDigitsExtractor;
import randomLib.numbers.util.Common;


/**
 * genera numeros al azar dado el metodo producto medio modificado
 * 
 * el constructor recibe por parametros la semilla, una constante k y el valance y las almacena en las variables
 * definidas en la superclase. menos la constante k que se almancena en una variable de esta clase
 * copia el valor original en la variable value (tambien de la super) y opera sobre este
 * cada nuevo valor de la iteracion es almacenado en value.
 *
 * @author JuanBC - JuanMG - FranciscoAG
 * @version 1.0
 */
public class ProdMedioModificado extends CenterMethod {

    //constante k
    private int k;

    /**
     * contructor
     * @param seed  semilla
     * @param k constante k
     * @param valance valance
     */
    public ProdMedioModificado(long seed, int k, int valance) {
        super(seed, valance);
        this.k = k;
        this.setTotalDigits();
    }
    
    /**
     * contructor recibe un double como semilla pero lo almacena como un long
     * @param seed  semilla
     * @param k constante k
     * @param valance valance
     */
    public ProdMedioModificado(double seed, int k, int valance) throws InvalidDoubleSeedsException {
        super(seed, valance);
        this.k = k;
        this.setTotalDigits();
    }
    

    /**
     *  calcula la formula del metodo
     * @param value0 - valor
     * @param value1 - no se usa
     * @return valor evaluado
     */
    @Override
    public long formula(long value0, long value1) {
        return value0 * k;
    }

    /**
     * retorna un nuevo valor de la iteracion
     * @return nuevo valor de la iteracion
     * @throws simRandom.exceptions.InsuficientDigitsException
     */
    @Override
    public long getNextLong() throws InsuficientDigitsException {
        long value = super.getValue();
        value = this.formula(value, 0);
        value = CenterDigitsExtractor.getDigits(value, super.digitToGet(), super.getTotalDigits(), super.getBalance());
        super.setValue(value);
        return super.getValue();
    }

    /**
     * carga la maxima cantidad de digitos posibles de extraer de esta semilla
     */
    @Override
    public void setTotalDigits() {
        long snod = Common.sameDigitsNine(super.getSeed());
        snod = this.formula(snod, 0);
        super.setTotalDigits(Common.getNumberOfDigits(snod));
    }

    /**
     * valor de la variable k
     * @return variable k
     */
    public int getK() {
        return k;
    }
    
    /**
     * genera un nuevo numero random de tipo double entre 0 y 1
     * @return un nuevo random
     * @throws simRandom.exceptions.InsuficientDigitsException
     */
    @Override
    public double getNextDouble() throws InsuficientDigitsException {
        double aux = Common.long2Double(this.getNextLong());
        return aux;
    }
}
