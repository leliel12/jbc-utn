/**
 *  InvalidDoubleSeedsException.java
 * 
 *  Copyright (C) - 27 de 2008 - juan b cabral
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package randomLib.numbers.exceptions;

/**
 * Clase que representa una excepcion lanzada al momento de ingresar semillas del tipo double
 * que no esta entre los valores 0 y 1
 * @author JuanBC - JuanMG - FranciscoAG
 * @version 1.0
 */
public class InvalidDoubleSeedsException extends Exception {

    /**
     * Creates a new instance of <code>DiferentSizesOfSeedsException</code> without detail message.
     */
    public InvalidDoubleSeedsException() {
        this("Seed debe estar entre 0 y 1");
    }


    /**
     * Constructs an instance of <code>DiferentSizesOfSeedsException</code> with the specified detail message.
     * @param msg the detail message.
     */
    public InvalidDoubleSeedsException(String msg) {
        super(msg);
    }
}
