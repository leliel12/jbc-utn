/*
 *  ExpNeg.java 
 * 
 *  Copyright (C) - 2008 - Juanbc
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
package randomLib.variables;

import java.util.logging.Level;
import java.util.logging.Logger;
import randomLib.numbers.exceptions.InsuficientDigitsException;
import randomLib.numbers.models.Method;
import randomLib.variables.models.Distribution;

/**
 * calculo de variables por exponencial negativa
 * @author JuanBC - JuanMG - FranciscoAG
 * @version 1.0
 */
public class ExpNeg<E extends Method> extends Distribution{

    //lambda
    private double lamb;
    
    /**
     * crea una nueva instancia de la clase
     * @param randomizer calculador de numeros aleatorios
     * @param lambda valor de lambda
     */
    public ExpNeg(E randomizer, double lambda){
        super(randomizer);
        this.lamb=lambda;
    }
    
    /**
     * un valor mas dentro de la distribucion
     * @return un nuevo valor
     */
    public double getNextDouble() {
        return this.getDoubles(1)[0];
    }

    /**
     * para que retorne <code>c</code> valores
     * @param c cantidad de valores
     * @return vector con todos los valores
     */
    public double[] getDoubles(int c) {
        double[] a=new double[c];
        Method r=super.getRand();
        for(int i=0; i<c;i++){
            try {
                a[i] = (1 / lamb) * Math.log(r.getNextDouble());
                a[i] = -1 * a[i];
                super.add(a[i]);
            } catch (InsuficientDigitsException ex) {
                Logger.getLogger(ExpNeg.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return a;
    }

    /**
     * para obtener el parametro lambda
     * @return lambda
     */
    public double getLambda() {
        return lamb;
    }

 
}
