/*
 *  Unif.java 
 * 
 *  Copyright (C) - 2008 - Juanbc
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
package randomLib.variables;

import java.util.logging.Level;
import java.util.logging.Logger;
import randomLib.numbers.exceptions.InsuficientDigitsException;
import randomLib.numbers.models.Method;
import randomLib.variables.models.Distribution;

/**
 * variables aleatorias por dist uniforme
 * @author JuanBC - JuanMG - FranciscoAG
 * @version 1.0
 */
public class Unif<E extends Method> extends Distribution {

    //constantes de a y b
    private double a;
    private double b;
    
    /**
     * crea una nueva instancia de la clase
     * @param randomizer calculador de numeros aleatorios
     * @param a limite inferior
     * @param b limite superior
     */
    public Unif(E randomizer, double a, double b) {
        super(randomizer);
        this.a=a;
        this.b=b;
    }

    /**
     * retorna un valor
     * @return nuevo valor
     */
    public double getNextDouble() {
        return this.getDoubles(1)[0];
    }

    /**
     * para que retorne <code>c</code> valores
     * @param c cantidad de valores
     * @return vector con todos los valores
     */
    public double[] getDoubles(int c) {
        Method r = super.getRand();
        double[] v = new double[c];
        for (int i = 0; i < c; i++) {
            try {
                v[i] = (b - a) * r.getNextDouble() + a;
                super.add(v[i]);
            } catch (InsuficientDigitsException ex) {
                Logger.getLogger(Unif.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return v;
    }

    /**
     * parametro a
     * @return limite inferior
     */
    public double getA() {
        return a;
    }

    /**
     * parametro b
     * @return limite superior
     */
    public double getB() {
        return b;
    }
}
