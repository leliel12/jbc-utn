/*
 *  Normal.java 
 * 
 *  Copyright (C) - 2008 - Juanbc
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
package randomLib.variables;

import java.util.logging.Level;
import java.util.logging.Logger;
import randomLib.numbers.exceptions.InsuficientDigitsException;
import randomLib.numbers.models.Method;
import randomLib.variables.models.Distribution;

/**
 * calculo de variables aleatorias por dist normal
 * @author JuanBC - JuanMG - FranciscoAG
 * @version 1.0
 */
public class Normal<E extends Method> extends Distribution {

    // media normal
    private double mu;
    //desviacion estandar normal
    private double sigma;

    /**
     * crea una nueva instancia de la clase
     * @param randomizer metodo para calculo de numeros aleatorios
     * @param mu media poblacional
     * @param sigma desviacion estandar poblacional
     */
    public Normal(E randomizer, double mu, double sigma) {
        super(randomizer);
        this.mu = mu;
        this.sigma = sigma;
    }

    /**
     * para que retorne el siguiente valoe
     * @return siguiente valor
     */
    public double getNextDouble() {
        return this.getDoubles(1)[0];
    }

    /**
     * para que retorne <code>c</code> valores
     * @param c cantidad de valores
     * @return vector con todos los valores
     */
    public double[] getDoubles(int c) {
        double[] a = new double[c];
        for (int i = 0; i < c; i++) {
            a[i] = mu + sigma * this.getZ();
            super.add(a[i]);
        }
        return a;
    }

    /**
     * media poblacional
     * @return media poblacional
     */
    public double getMu() {
        return mu;
    }

    /**
     * desviacion estandar poblacional
     * @return desv estandar poblacional
     */
    public double getSigma() {
        return sigma;
    }

    // par calculo de numero aleatorio
    private double getZ() {
        Method r = super.getRand();
        double z = 0;
        try {

            z = -2 * Math.log(r.getNextDouble());
            z = Math.sqrt(z);
            z = z * Math.sin(2 * Math.PI * r.getNextDouble());

        } catch (InsuficientDigitsException ex) {
            Logger.getLogger(Normal.class.getName()).log(Level.SEVERE, null, ex);
        }
        return z;
    }
}
