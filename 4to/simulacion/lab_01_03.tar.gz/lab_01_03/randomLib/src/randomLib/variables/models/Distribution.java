/*
 *  Distribution.java 
 * 
 *  Copyright (C) - 2008 - Juanbc
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
package randomLib.variables.models;

import java.util.ArrayList;
import randomLib.numbers.models.Method;

/**
 *
 * @author JuanBC - JuanMG - FranciscoAG
 * @version 1.0
 */
public abstract class Distribution<E extends Method> implements DistInterface {

    private ArrayList<Double> values;
    private E rand;

    /**
     * nueva instancia
     * @param randomizer el calculador de numeros aleatorios
     */
    public Distribution(E randomizer) {
        this.rand = randomizer;
        values = new ArrayList<Double>();
    }//constructor
    
    /**
     * la media de los valores
     * @return la media
     */
    public double media(){
        double media=0;
        for(int i=0;i<values.size();i++){
            media=values.get(i).doubleValue();
        }
        if(values.size()>0) media=media/values.size();
        return media;
    }
  
    /**
     * retorna todos los valores calculados hasta el momento
     * @return un vector con todos los valores
     */
    public double[] getAllValues(){
        double[] a= new double[values.size()];
        for(int i=0;i<values.size();i++){
            a[i]=values.get(i).doubleValue();
        }
        return a;
    }
    
    /**
     * agrega un valor a los calculados
     * @param d nuevo double pa la coleccion
     */
    public void add(double d){
        values.add(new Double(d));
    }
    
    /**
     * calcula la desviacion estandar de los valores calculados hasta el momento
     * @return desviacion estandar
     */
    public double deviation(){
        double des=0;
        double media=this.media();
        for(int i=0; i<values.size();i++){
            double a=values.get(i).doubleValue() - media;
            a= a*a;
            des=des+a;
        }
        des = des/(values.size()-1);
        return Math.sqrt(des);
    }
    
    /**
     * el valor maximo de la serie hasta el momento
     * @return maximo valor
     */
    public double max(){
        double max=0;
        for(int i=0; i<values.size();i++){
            if(values.get(i)>max) max=values.get(i);
        }
        return max;
    }
    
    /**
     * el minimo valor de lo calculado
     * @return el mas chiquito
     */
    public double min(){
        double min=0;
        if(values.size()>0) min=values.get(0);
        for(int i=0; i<values.size();i++){
            if(values.get(i)>min) min=values.get(i);
        }
        return min;
    }
    
    /**
     * el recorrido osea o el valor maximo menos el minimo
     * @return recorrido
     */
    public double road(){
        return this.max() - this.min();
    }

    public E getRand() {
        return rand;
    }
    
    
}
