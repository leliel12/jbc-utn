/**
 *  HistogramaJPanel.java
 * 
 *  Copyright (C) - 2008 - JBCabral - JMGuzman - FAGambino
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package graphicLib;


/**
 * clase de utilidad
 * @author JBCabral - JMGuzman - FAGambino
 * @version 1.0
 */
abstract class Util
{

    public static float simetricFloat(float f, int n){
        return (float)simetricDouble(f,n);
    }
    
    public static double simetricDouble(double d, int n){
        try{
            d=truncateDouble(d,n+1); // trunco con un valor de mas
            String str= String.valueOf(d); // convierto a una cadena
            str=String.valueOf(str.charAt(str.length()-1)); // extraigo el digito extra
            int c=Integer.parseInt(str); // convierto el valor extra en un int
            d=truncateDouble(d,n); // quito el valor extra
            if(c>4)  d=d+increment(d,n); // si el valor extra es mas grande que cuatro se incrementa en uno el valor anterior
        }catch(Exception e){} finally{return d;}
    }
    
    public static float truncateFloat(float f, int n){
        return (float)truncateDouble(f,n);
    }
    
    public static double truncateDouble(double d,int n){
        String str= String.valueOf(d);
        int dot=str.indexOf(".");
        try{
            str=str.substring(0,dot+n+1);d=Double.parseDouble(str);
        }catch(Exception e){} finally {return d;}
    }
    
    // calcula el incrmento para redondear simetricamente
    private static double increment(double d,int n) throws Exception{
        String str="0.";
        for(int i=0;i<n-1;i++){
            str=str+"0";
        }
        return Double.parseDouble(str + "1");
    }
    
    
    

}
