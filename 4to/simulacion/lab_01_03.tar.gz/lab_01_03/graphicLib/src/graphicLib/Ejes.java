package graphicLib;
/**
 *  Ejes.java
 * 
 *  Copyright (C) - 2008 - JBCabral - JMGuzman - FAGambino
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Clase que dibuja los ejes del grafico
 * @author JBCabral - JMGuzman - FAGambino
 * @version 1.0
 */
class Ejes {
    
    //variables de eje
    private int largoEjeX;
    private int largoEjeY;
    private int origenX;
    private int origenY;
    
    /**
     * Creates a new instance of Ejes 
     * @param lX largo de eje x
     * @param lY largo eje y
     * @param oX origen de x
     * @param oY origen de y
     */
    public Ejes(int lX,int lY,int oX,int oY) {
        this.largoEjeX = lX;
        this.largoEjeY = lY;
        this.origenX = oX;
        this.origenY = oY;
    }

    /**
     * largo del eje x
     * @return largo del eje x
     */
    public int getLargoEjeX() {
        return largoEjeX;
    }

    /**
     * largo del eje y
     * @param largoEjeX largo del eje x
     */
    public void setLargoEjeX(int largoEjeX) {
        this.largoEjeX = largoEjeX;
    }

    /**
     * largo del eje y
     * @return largo del eje y
     */
    public int getLargoEjeY() {
        return largoEjeY;
    }

    /**
     * largo del eje y
     * @param largoEjeY largo del eje y
     */
    public void setLargoEjeY(int largoEjeY) {
        this.largoEjeY = largoEjeY;
    }

    /**
     * origen de x
     * @return origen de x
     */
    public int getOrigenX() {
        return origenX;
    }

    /**
     * origen de x
     * @param origenX origen de x
     */
    public void setOrigenX(int origenX) {
        this.origenX = origenX;
    }

    /**
     * origen de y
     * @return origen de y
     */
    public int getOrigenY() {
        return origenY;
    }

    /**
     * origen de y 
     * @param origenY origen de y
     */
    public void setOrigenY(int origenY) {
        this.origenY = origenY;
    }
    
}
