/**
 *  Ejes.java
 * 
 *  Copyright (C) - 2008 - JBCabral - JMGuzman - FAGambino
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


package graphicLib;

/**
 * genera los intervalos
 * @author JBCabral - JMGuzman - FAGambino
 * @version 1.0
 */
class IntervalGenerator {

    //variables
    private double maxvector;
    private double minvector;
    private Intervalo[] vConstruir;

    /**
     * contruye una nueva instancia
     * @param v vector de valores
     * @param cantIntervalos cantidad de intervalos
     */
    public IntervalGenerator(double[] v,int cantIntervalos){
        this.construirIntervalos(cantIntervalos, v);
        this.setValoresIntervalo(v);   
    }
    
    public Intervalo[] getIntervalos(){
        return this.vConstruir;
    }
    
    /**
     * retorna el recorrido
     * @param v los valores
     * @return recorridp
     */
    public double getRecorrido(double[] v) {
        int i;
        double max, min, recorrido;
        max = 0;
        min = 1;
        for (i = 0; i < v.length - 1; i++) {
            if (v[i] > max)
                max = v[i];
            
            if (v[i] < min)
                min = v[i];          
        }
        setMaxvector(max);
        setMinvector(min);
        return (max - min);
    }

    /**
     * contruye los intervalos
     * @param cantIntervalos cantidad de intervalos
     * @param v valores
     */
    public void construirIntervalos(int cantIntervalos, double[] v) {
        vConstruir = new Intervalo[cantIntervalos];
        int i;
        double anchoIntevalo;
        anchoIntevalo = getRecorrido(v) / cantIntervalos;
        for (i = 0; i < cantIntervalos; i++) {
            if (i == 0) {
                vConstruir[i] = new Intervalo(minvector, minvector + anchoIntevalo);
            } else {
                vConstruir[i] = new Intervalo(vConstruir[i - 1].getLsuperior(), vConstruir[i - 1].getLsuperior() + anchoIntevalo);
            }
        }
        this.completeIntervalo();
    }

    //completa los intervalos con un intervalo vacios al comienzo y al final
    private void completeIntervalo() {
        Intervalo v[] = new Intervalo[this.vConstruir.length + 2];
        for (int i = 1; i < v.length - 1; i++) {
            v[i] = vConstruir[i - 1];
        }
        v[0] = new Intervalo();
        v[v.length - 1] = new Intervalo();
        v[0].setLsuperior(v[1].getLinferior());
        v[0].setLinferior(v[0].getLsuperior() - v[1].getAmplitud());
        v[v.length - 1].setLinferior(v[v.length - 2].getLsuperior());
        v[v.length - 1].setLsuperior(v[v.length - 1].getLinferior() + v[v.length - 1].getAmplitud());
        v[0].setMarcaClase();
        v[v.length - 1].setMarcaClase();
        vConstruir = v;
    }

    // Controla los intervalos y setea la frecuencia de los valores dados en el vetor de dobles aleatorios
    private void setValoresIntervalo(double[] v) {
        int i, j;
        for (i = 0; i < v.length; i++) {
            for (j = 0; j < vConstruir.length; j++) {
                if (vConstruir[j].perteneceIntervalo(v[i])) {
                    vConstruir[j].setFrecuencia();
                    break;
                }
            }
        }
    }

    /**
     * maximo del vector
     * @return el valor maximo que tiene el vector de doubles
     */
    private double getMaxvector() {
        return maxvector;
    }

    
    /**
     * setea el maximo del vector
     * @param maxvector maximo valor del vector
     */
    public void setMaxvector(double maxvector) {
        this.maxvector = maxvector;
    }
//
//    public double getMinvector() {
//        return minvector;
//    }
//
    /**
     * minimo valor del vector
     * @param minvector minimo valor del vector
     */
    public void setMinvector(double minvector) {
        this.minvector = minvector;
    }
}
