/*
 *  Prac3JPanel.java 
 * 
 *  Copyright (C) - 2008 - JBCabral - JMGuzman - FAGambino
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
package core.view;

import core.back.Gears3;

/**
 * panel con ejecrcicios del practico 3
 * @author JBCabral - JMGuzman - FAGambino
 * @version 1.0
 */
public class Prac3JPanel extends javax.swing.JPanel {

    private double lambda;
    private double mu;
    private double sigma;
    private double a;
    private double b;
    private int n;
    private Gears3 prac3;
    private String gen;

    /** Creates new form Prac3JPanel */
    public Prac3JPanel() {
        initComponents();
        this.enableDisableFields();
        prac3=new Gears3();
    }

    //ativa o desactiva campos segun el generador de variables elegido
    public void enableDisableFields() {
        if (this.isGeneratorActive("Exponecial Negativa") || this.isGeneratorActive("Poisson")) {
            this.lambTextField.setEnabled(true);
            this.aTextField.setEnabled(false);
            this.bTextField.setEnabled(false);
            this.muTextField.setEnabled(false);
            this.sigTextField.setEnabled(false);
        }
        if (this.isGeneratorActive("Normal (Gaussiana)")) {
            this.lambTextField.setEnabled(false);
            this.aTextField.setEnabled(false);
            this.bTextField.setEnabled(false);
            this.muTextField.setEnabled(true);
            this.sigTextField.setEnabled(true);
        }
        if (this.isGeneratorActive("Uniforme")) {
            this.lambTextField.setEnabled(false);
            this.aTextField.setEnabled(true);
            this.bTextField.setEnabled(true);
            this.muTextField.setEnabled(false);
            this.sigTextField.setEnabled(false);
        }
        this.validateFields();
    }

    // valida que los valores ingresados sean correctos
    public void validateFields() {
        String info = "";
        boolean enable = true;
        jTextArea1.setForeground(new java.awt.Color(253, 110, 67));

        try {
            if (this.nTextField.isEnabled()) {
                this.n = Integer.parseInt(this.nTextField.getText());
            } else {
                this.n = 0;
            }
        } catch (Exception e) {
            info += "err>> Cantidad de valores no es un numero...\n";
            enable = false;
        }
        
        try {
            if (this.lambTextField.isEnabled()) {
                this.lambda = Double.parseDouble(this.lambTextField.getText());
            } else {
                lambda = 0;
            }
        } catch (Exception e) {
            info += "err>> Lambda no es un numero...\n";
            enable = false;
        }

        try {
            if (this.muTextField.isEnabled()) {
                this.mu = Double.parseDouble(this.muTextField.getText());
            } else {
                mu = 0;
            }
        } catch (Exception e) {
            info += "err>> La Media Poblacional no es un numero...\n";
            enable = false;
        }

        try {
            if (this.sigTextField.isEnabled()) {
                this.sigma = Double.parseDouble(this.sigTextField.getText());
            } else {
                sigma = 0;
            }
        } catch (Exception e) {
            info += "err>> La Desviacion Poblacional no es un numero...\n";
            enable = false;
        }

        try {
            if (this.aTextField.isEnabled()) {
                this.a = Double.parseDouble(this.aTextField.getText());
            } else {
                a = 0;
            }
        } catch (Exception e) {
            info += "err>> A no es un numero...\n";
            enable = false;
        }

        try {
            if (this.bTextField.isEnabled()) {
                this.b = Double.parseDouble(this.bTextField.getText());
            } else {
                b = 0;
            }
        } catch (Exception e) {
            info += "err>> B no es un numero...\n";
            enable = false;
        }

        if (enable) {
            jTextArea1.setForeground(new java.awt.Color(172, 241, 99));
            info = "Todos los valores estan ok!";
        }
        this.jButton1.setEnabled(enable);
        this.jTextArea1.setText(info);
    }

    private boolean isGeneratorActive(String str) {
        return (((String) this.jComboBox1.getSelectedItem()).compareTo(str) == 0);
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jComboBox1 = new javax.swing.JComboBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        nTextField = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        lambTextField = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        muTextField = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        sigTextField = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        bTextField = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        aTextField = new javax.swing.JTextField();
        grafButton = new javax.swing.JButton();

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Exponecial Negativa", "Normal (Gaussiana)", "Poisson", "Uniforme" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jTable1.setModel(new TableModel());
        jScrollPane1.setViewportView(jTable1);

        jScrollPane2.setBorder(javax.swing.BorderFactory.createTitledBorder("Info"));

        jTextArea1.setBackground(new java.awt.Color(1, 1, 1));
        jTextArea1.setColumns(20);
        jTextArea1.setEditable(false);
        jTextArea1.setForeground(new java.awt.Color(253, 110, 67));
        jTextArea1.setLineWrap(true);
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        jButton1.setText("Get Variables!");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Reset");
        jButton2.setEnabled(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jPanel1.setLayout(new java.awt.GridLayout(6, 3, 5, 5));

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel6.setText("Cantidad de Valores");
        jPanel1.add(jLabel6);

        nTextField.setText("1000");
        nTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                nTextFieldKeyReleased(evt);
            }
        });
        jPanel1.add(nTextField);

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel1.setText("Lambda");
        jPanel1.add(jLabel1);

        lambTextField.setText("30");
        lambTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                lambTextFieldKeyReleased(evt);
            }
        });
        jPanel1.add(lambTextField);

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel2.setText("Media Poblacional");
        jPanel1.add(jLabel2);

        muTextField.setText("0");
        muTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                muTextFieldKeyReleased(evt);
            }
        });
        jPanel1.add(muTextField);

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel3.setText("Desviacion Poblacional");
        jPanel1.add(jLabel3);

        sigTextField.setText("1");
        sigTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                sigTextFieldKeyReleased(evt);
            }
        });
        jPanel1.add(sigTextField);

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel4.setText("a >>>>>>>>>>>>");
        jPanel1.add(jLabel4);

        bTextField.setText("1");
        bTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                bTextFieldKeyReleased(evt);
            }
        });
        jPanel1.add(bTextField);

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel5.setText("b >>>>>>>>>>>>");
        jPanel1.add(jLabel5);

        aTextField.setText("0");
        aTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                aTextFieldKeyReleased(evt);
            }
        });
        jPanel1.add(aTextField);

        grafButton.setText("Grafico");
        grafButton.setEnabled(false);
        grafButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                grafButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox1, 0, 331, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 331, Short.MAX_VALUE))
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 331, Short.MAX_VALUE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(grafButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 156, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 631, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 680, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(grafButton)
                        .addGap(42, 42, 42)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 374, Short.MAX_VALUE)))
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents
    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        this.enableDisableFields();
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void lambTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_lambTextFieldKeyReleased
        this.validateFields();
    }//GEN-LAST:event_lambTextFieldKeyReleased

    private void muTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_muTextFieldKeyReleased
        this.validateFields();
    }//GEN-LAST:event_muTextFieldKeyReleased

    private void aTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_aTextFieldKeyReleased
        this.validateFields();
    }//GEN-LAST:event_aTextFieldKeyReleased

    private void sigTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_sigTextFieldKeyReleased
        this.validateFields();
    }//GEN-LAST:event_sigTextFieldKeyReleased

    private void bTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_bTextFieldKeyReleased
        this.validateFields();
    }//GEN-LAST:event_bTextFieldKeyReleased

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        this.disableEnable(true);
        this.enableDisableFields();
        this.jTable1.setModel(new TableModel());
    }//GEN-LAST:event_jButton2ActionPerformed

    private void nTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nTextFieldKeyReleased
    this.validateFields();
}//GEN-LAST:event_nTextFieldKeyReleased

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        this.disableEnable(false);
        gen=(String) this.jComboBox1.getSelectedItem();
        prac3.reset(gen, lambda, mu, sigma, a, b, n);
        double[] values=prac3.getValues();
        TableModel tm=new TableModel(values);
        this.jTable1.setModel(tm);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void grafButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_grafButtonActionPerformed
        String tit=((String) this.jComboBox1.getSelectedItem());
        double[] values=((TableModel)this.jTable1.getModel()).getValues();
        GraphJDialog.show(values, tit);
}//GEN-LAST:event_grafButtonActionPerformed

    //cuando se piden los valores se encarga de blokear los campos
    private void disableEnable(boolean b){
        this.jComboBox1.setEnabled(b);
        this.sigTextField.setEnabled(b);
        this.aTextField.setEnabled(b);
        this.bTextField.setEnabled(b);
        this.muTextField.setEnabled(b);
        this.nTextField.setEnabled(b);
        this.lambTextField.setEnabled(b);
        this.jButton1.setEnabled(b);
        this.jButton2.setEnabled(!b);
        this.grafButton.setEnabled(!b);
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField aTextField;
    private javax.swing.JTextField bTextField;
    private javax.swing.JButton grafButton;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField lambTextField;
    private javax.swing.JTextField muTextField;
    private javax.swing.JTextField nTextField;
    private javax.swing.JTextField sigTextField;
    // End of variables declaration//GEN-END:variables
}
