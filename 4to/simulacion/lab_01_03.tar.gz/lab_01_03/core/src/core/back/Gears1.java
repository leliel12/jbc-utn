/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package core.back;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import randomLib.numbers.CongAditivo;
import randomLib.numbers.CongMixta;
import randomLib.numbers.CuadradoMedio;
import randomLib.numbers.JavaRandom;
import randomLib.numbers.MultDeCongruencia;
import randomLib.numbers.ProdMedio;
import randomLib.numbers.ProdMedioModificado;
import randomLib.numbers.exceptions.DiferentSizesOfSeedsException;
import randomLib.numbers.exceptions.InsuficientDigitsException;
import randomLib.numbers.exceptions.InvalidDoubleSeedsException;
import randomLib.numbers.models.Method;


/**
 *
 * @author juan
 */
public class Gears1 {

    private Method met;
    private ArrayList<Double> values = new ArrayList<Double>();

    public void reset(String method, double seed0, double seed1, int k, int a, int c, int balance) throws InvalidDoubleSeedsException, DiferentSizesOfSeedsException {
        values = new ArrayList<Double>();
        if (this.isSelectedMethod("Congruente Aditivo", method)) {
            met = new CongAditivo(seed0, seed1, k);
        }
        if (this.isSelectedMethod("Multiplicador de Congruencia", method)) {
            met = new MultDeCongruencia(seed0, a, k);
        }
        if (this.isSelectedMethod("Congruencia Mixta", method)) {
            met = new CongMixta(seed0, a, k, c);
        }
        if (this.isSelectedMethod("Producto Medio Modificado", method)) {
            met = new ProdMedioModificado(seed0, k, balance);
        }
        if (this.isSelectedMethod("Java Random", method)) {
            met = new JavaRandom(seed0);
        }
        if (this.isSelectedMethod("Cuadrado Medio", method)) {
            met = new CuadradoMedio(seed0, balance);
        }
        if (this.isSelectedMethod("Producto Medio", method)) {
            met = new ProdMedio(seed0, seed1, balance);
        }
        System.gc();
    }

    public double[] getValues() {
        if (values.size()>1) {
            this.addValues(1);
        } else {
            this.addValues(20);
        }
        double[] d=new double[values.size()];
        for(int i=0;i<values.size();i++){
            d[i]=values.get(i).doubleValue();
        }
        return d;
    }

    private void addValues(int n) {
        try {
            for (int i = 0; i < n; i++) {
                double d = met.getNextDouble();
                this.values.add(new Double(d));
            }

        } catch (InsuficientDigitsException ex) {
            Logger.getLogger(Gears1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private boolean isSelectedMethod(String arg0, String arg1) {
        return (arg0.compareTo(arg1) == 0);
    }
}
