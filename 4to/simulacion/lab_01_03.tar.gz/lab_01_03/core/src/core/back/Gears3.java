/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package core.back;

import java.util.Random;
import randomLib.numbers.JavaRandom;
import randomLib.numbers.exceptions.InvalidDoubleSeedsException;
import randomLib.variables.ExpNeg;
import randomLib.variables.Normal;
import randomLib.variables.Poisson;
import randomLib.variables.Unif;
import randomLib.variables.models.Distribution;



/**
 *
 * @author juan
 */
public class Gears3 {

    private Distribution gen;
    private JavaRandom rand;
    private int n;
    //private ArrayList<Double> values = new ArrayList<Double>();
    
    public void reset(String generador, double lambda, double mu, double sigma, double a, double b, int n) {
        this.n=0;
        try {
            rand = new JavaRandom(new Random().nextDouble());
            gen = null;
        } catch (InvalidDoubleSeedsException ex) {}
        if (isSelectedMethod("Exponecial Negativa", generador)) {
                gen = new ExpNeg(rand, lambda);
            }
            if (isSelectedMethod("Normal (Gaussiana)", generador)) {
                gen = new Normal(rand, mu, sigma);
            }
            if (isSelectedMethod("Poisson", generador)) {
                gen = new Poisson(rand, lambda);
            }
            if (isSelectedMethod("Uniforme", generador)) {
                gen = new Unif(rand, a, b);
            }
        this.n=n;
    }

    public double[] getValues() {
        gen.getDoubles(n);
        return gen.getAllValues();
    }
        
   private boolean isSelectedMethod(String arg0, String arg1) {
        return (arg0.compareTo(arg1) == 0);
    }
}
