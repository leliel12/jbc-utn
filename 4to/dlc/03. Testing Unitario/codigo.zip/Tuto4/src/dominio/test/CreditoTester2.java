package dominio.test;
import dominio.Cuenta;
import dominio.Movimiento;
import dominio.Tarjeta;
import java.util.Date;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import dominio.Credito;

public class CreditoTester2 extends TarjetaTester1 
{
	Credito tarjeta;

	public CreditoTester2(String sTestName)
	{
		super(sTestName);
	}

	public void setUp() throws Exception
	{
		super.setUp();
		Date hoy=new Date();
		long tiempo=Long.parseLong("12096000000");
		Date fecha=new Date(hoy.getTime()+ tiempo); // Caduca en 4 a�os
		tarjeta=new Credito("1234567890123456", "Fulano de Tal", fecha, 1000.0);
		tarjeta.setCuenta(cuenta);		
	}

	public void tearDown() throws Exception
	{
	}
	
	public Tarjeta tarjetaInicial() 
	{
		return tarjeta;
	}
	
	public Tarjeta preparaTarjeta(Cuenta c) 
	{
		Tarjeta t=new Credito("9876543210987654", "Paco Pil", null, 1000.0);
		t.setCuenta(c);
		Movimiento m=new Movimiento();
		m.setImporte(-315.0);
		((Credito) t).addMovimiento(m);
		return t;
	}
	
	public static void main(String args[]) 
	{
		junit.swingui.TestRunner.run(CreditoTester2.class);
	}		
}