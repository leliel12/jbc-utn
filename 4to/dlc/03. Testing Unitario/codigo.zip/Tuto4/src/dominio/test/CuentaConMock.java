package dominio.test;
import com.mockobjects.sql.MockPreparedStatement;
import com.mockobjects.sql.MockMultiRowResultSet;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import dominio.Cuenta;
import com.mockobjects.sql.MockConnection2;

public class CuentaConMock extends TestCase 
{
	Cuenta cuenta;
	MockConnection2 bd;

	public CuentaConMock(String sTestName)
	{
		super(sTestName);
	}

	public void setUp() throws Exception
	{
		bd=new MockConnection2();
	}

	public void tearDown() throws Exception
	{
		bd.close();
	}
	
	public void testMaterializarCuenta() throws Exception 
	{
		MockPreparedStatement p=new MockPreparedStatement();
		bd.setupAddPreparedStatement("Select Numero, Titular from Cuenta where Numero=?", p);
		p.addExpectedSetParameter(1, "0001.0002.12.1234567890");
		MockMultiRowResultSet r=new MockMultiRowResultSet();
		r.setupColumnNames(new String[] {"Numero", "Titular"});
		Object[][] data=new Object[][] { 
																	{"0001.0002.12.1234567890", "Fulano de Tal"} 
																};
		r.setupRows(data);
		r.setExpectedNextCalls(2);
		p.addResultSet(r);
		cuenta=new Cuenta("0001.0002.12.1234567890", bd);		
		bd.verify();
	}
	
	public static void main(String args[]) 
	{
		junit.swingui.TestRunner.run(CuentaConMock.class);
	}	
}