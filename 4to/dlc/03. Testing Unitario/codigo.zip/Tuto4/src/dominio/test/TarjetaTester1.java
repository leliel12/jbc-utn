package dominio.test;
import dominio.Cuenta;
import dominio.Debito;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import dominio.Tarjeta;

public abstract class TarjetaTester1 extends TestCase 
{
	Debito tarjeta;
	Cuenta cuenta;

	public TarjetaTester1(String sTestName)
	{
		super(sTestName);
	}
	
	public void setUp() throws Exception
	{
		cuenta=new Cuenta("0001.0002.12.1234567890", "Fulano de Tal");
		cuenta.ingresar(1000.0);
	}	
	
	public abstract Tarjeta preparaTarjeta(Cuenta c);
	public abstract Tarjeta tarjetaInicial();
	
	public void testRetirar300() 
	{
		try 
		{
			Tarjeta tarjeta=tarjetaInicial();  	
			tarjeta.retirar(300.0);
			/* El siguiente asserts me fallaba en CreditoTester2, 
				porque las tarjetas de cr�dito cargan una comisi�n.
			*/
			//assertEquals(saldoInicial-300, tarjeta.getSaldo(), 0.0);
			
			Cuenta c=new Cuenta("1234.5678.12.1234567891", "Paco Pil");
			Tarjeta esperada=this.preparaTarjeta(c);
			assertTrue(tarjeta.getSaldo()==esperada.getSaldo());
		}
		catch (Exception e) 
		{
		}
	}
}