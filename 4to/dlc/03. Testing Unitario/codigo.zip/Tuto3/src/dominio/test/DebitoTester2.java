package dominio.test;
import dominio.Tarjeta;
import java.util.Date;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import dominio.Debito;
import dominio.Cuenta;

public class DebitoTester2 extends TarjetaTester1 
{
	public DebitoTester2(String sTestName)
	{
		super(sTestName);
	}

	public void setUp() throws Exception
	{
		super.setUp();
		Date hoy=new Date();
		long tiempo=Long.parseLong("12096000000");
		Date fecha=new Date(hoy.getTime()+ tiempo); // Caduca en 4 a�os
		tarjeta=new Debito("1234567890123456", "Fulano de Tal", fecha);
		tarjeta.setCuenta(cuenta);		
	}

	public void tearDown() throws Exception
	{
	}
	
	public Tarjeta tarjetaInicial() 
	{
		return tarjeta;
	}
	
	public Tarjeta preparaTarjeta(Cuenta c) 
	{
		Tarjeta t=new Debito("9876543210987654", "Paco Pil", null);
		t.setCuenta(cuenta);
		return t;
	}
	
	public static void main(String args[]) 
	{
		junit.swingui.TestRunner.run(DebitoTester2.class);
	}		
}